<script>
import axios from "axios";

export default {
  data() {
    return {
      process_count: 0,
      running_process: -1,
      ready_processes: null,
      device_waiting: null,
      isError: false,
      intervalId: null,
    }
  },
  methods: {
    getProcessStatus() {
      axios.get("http://localhost:2333/api/get-process-status").then(res => {
        const error = res.data.error;
        if (error != null) {
          this.isError = true;
        } else {
          this.process_count = res.data.process_count;
          this.running_process = res.data.running_pid;
          this.ready_processes = res.data.ready_queue;
          this.device_waiting = res.data.waiting_queue;
        }
      }).catch(err => {
        this.isError = true;
      }).finally(() => {
        if(this.isError) {
          const time = new Date().toTimeString();
          this.$store.commit('setLogString', '[' + time + ']' + "failed to get process status")
        }
        this.isError = false;
      });
    }
  },
  mounted() {
    this.intervalId = setInterval(this.getProcessStatus, 100);
  },
  unmounted() {
    clearInterval(this.intervalId);
  }
}

</script>

<template>
  <a-space :direction="'vertical'" fill>
    <p>进程监视器</p>
    <p>进程数：{{this.process_count}}</p>
    <a-divider />
    <h2>Running</h2>
    <p v-if="this.running_process !== -1">PID：{{this.running_process}}</p>
    <p v-else>No running process</p>
    <a-divider />
    <h2>Ready</h2>
    <a-list max-height="200">
      <a-list-item v-for="process in this.ready_processes">
        {{process}}
      </a-list-item>
    </a-list>
    <a-divider />
    <h2>Waiting</h2>
    <a-list :grid-props="{ gutter: 0, span: 12 }" :bordered="false">
      <a-list-item v-for="(queue, index) in this.device_waiting">
        <a-list>
          <template #header v-if="index !== 0">设备{{index}}</template>
          <template #header v-else>磁盘</template>
          <a-list-item v-for="process in queue">
            {{process}}
          </a-list-item>
        </a-list>
      </a-list-item>
    </a-list>
  </a-space>
</template>

<style scoped>

</style>