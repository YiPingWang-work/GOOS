package Process
//系统调用
import (
	"GOOS/Global"
	"GOOS/Hardware"
	"GOOS/Interrupt"
	"GOOS/OS/FileSystem"
	"GOOS/OS/IO"
	"GOOS/OS/MemmorySystem"
	"GOOS/OS/PCBManage"
	"errors"
	"fmt"
)

/*
type Trap struct {
	Type int //类型
	Priority int //优先级
	Pid int //请求/返回中断的进程id
	//新建进程要给出的磁盘物理位置
	PhysicalDiskPage []int
	//缺页
	LogicPageNum int //处理缺页中断的缺页的逻辑页号
	//文件
	FileLogicAddress int //请求文件的逻辑位置
	FilePath string //请求文件的文件名
	FileSiz int //文件大小
	//设备
	Device int //请求设备的设备名
	//内存
	MemSiz int
	//其他
	Command string //命令号（未实现）
}
*/

func SystemCall(trap Interrupt.Trap) (err error){
	pid := PCBManage.RunningPID
	switch trap.Type {
	case Interrupt.STDIN: //请求标准输入
		err = stdin(pid)

	case Interrupt.STDOUT: //请求标准输出
		err = stdout(pid)

	case Interrupt.NEWPROCESS: //新建进程
		err = newProcess(pid, &trap.PhysicalDiskPage)

	case Interrupt.MEMORYAPPLY: //内存请求
		err = memoryApply(pid, trap.MemSiz)

	case Interrupt.CREATEFILE: //创建文件请求
		createFileByPath(pid, trap.FilePath)

	case Interrupt.OPENFILE: //打开文件请求
		err = openFile(pid, trap.FilePath)

	case Interrupt.READFILE://读文件请求
		err = readFile(pid, trap.FilePath, trap.FileLogicAddress, trap.FileSiz)

	case Interrupt.WRITEFILE: //写文件请求
		err = writeFile(pid, trap.FilePath, trap.FileLogicAddress, trap.Command)

	case Interrupt.CLOSEFILE:
		err = closeFile(pid, trap.FilePath)

	case Interrupt.ABORTPROCESS: //进程终止
		err = abortProcess(pid)

	case Interrupt.PAGEFAULT: //缺页
		err = swap(pid, trap.LogicPageNum)

	case Interrupt.DEVICEAPPLY: //请求设备
		err = deviceApply(pid, trap.Device)

	case Interrupt.UNDEFINE1://用户中断，该中断可以被中断
		run(&trap)

	case Interrupt.DEVICEINSTALL:
		installDevice(pid, trap.Device)

	default:
		err = errors.New("illegal trap")
	}
	return
}

func stdin(pid int) (err error) { //当前进程请求标准输入，暂时不实现
	return
}

func stdout(pid int) (err error) { //当前进程请求标准输出，暂时不实现
	return
}

func newProcess(pid int, physicalDiskPage *[]int) (err error) { //当前进程新建作业/程序
	_, err = PCBManage.New(pid, physicalDiskPage)
	fmt.Println("SystemCall/此时Readyqueue=",PCBManage.ReadyQueue)
	return
}

func memoryApply(pid int, siz int) (err error) { //当前进程申请内存资源
	err = MemmorySystem.MemoryAllocate(pid, siz)
	return
}

func createFileByPath(pid int, name string) {
	fmt.Println("SystemCall/创建文件,pid",pid,"文件名",name)
	Global.LOGS = fmt.Sprintf("SystemCall/创建文件,pid:%d,文件名:%s",pid,name)
	FileSystem.CreateFileByPath(name, 0)
}

func openFile(pid int, filePath string) (err error) { //打开文件，将文件描述符加入到进程的打开文件表中
	fd := FileSystem.OpenFileByPath(filePath, pid)
	fmt.Println("SystemCall/打开文件,pid",pid,"文件名",filePath,"返回文件描述符",fd)
	Global.LOGS = fmt.Sprintf("SystemCall/打开文件,pid:%d,文件名:%s,返回文件描述符:",pid,filePath,fd)
	PCBManage.PCBs[pid].FileTable[filePath] = fd
	Hardware.Memory.Buffer[pid] = append(Hardware.Memory.Buffer[pid], []byte{})
	fmt.Println("打开文件表为")
	for i,val := range(PCBManage.PCBs[pid].FileTable) {
		fmt.Println(i, val)
	}
	return
}

func readFile(pid int, name string, logicAddress int, siz int) (err error) { //当前进程读文件中断
	fd := PCBManage.PCBs[pid].FileTable[name]
	fmt.Println("SystemCall/读文件,pid",pid,"文件名",name,"返回文件描述符",fd,"逻辑起始位置",logicAddress,"长度",siz)
	Global.LOGS = fmt.Sprintf("SystemCall/读文件,pid:%d,文件名:%s,返回文件描述符:%d,逻辑起始:%d,长度:%d",pid,name,fd,logicAddress,siz)
	PCBManage.Waiting(Global.MEM_DISK)

	//不真实的读过程
	t := FileSystem.ReadFile(fd, logicAddress, siz, pid) //要求修改全局文件表
	//fmt.Println("---------------------------------------------------------------------------------------------------------------------------------------",string(t))
	//把data放到内存Buffer中
	Hardware.Memory.Buffer[pid][fd] = append(Hardware.Memory.Buffer[pid][fd], t...)
	return
}

func writeFile(pid int, name string, logicAddress int, content string) (err error) { //当前进程写文件中断
	fd := PCBManage.PCBs[pid].FileTable[name]
	t := []byte(content)
	fmt.Println("SystemCall/写文件,pid",pid,"文件名",name,"返回文件描述符",fd,"逻辑起始位置",logicAddress,"写的内容",string(t))
	Global.LOGS = fmt.Sprintf("SystemCall/写文件,pid:%d,文件名:%s,返回文件描述符:%d,逻辑起始位置:%d,写的内容:%s",pid,name,fd,logicAddress,string(t))
	PCBManage.Waiting(Global.MEM_DISK)
	FileSystem.WriteFile(fd, logicAddress, t, pid)
	return
}

func closeFile(pid int, name string) (err error) {
	fd := PCBManage.PCBs[pid].FileTable[name]
	fmt.Println("SystemCall/关闭文件,pid",pid,"文件名",name,"文件描述符",fd)
	Global.LOGS = fmt.Sprintf("SystemCall/关闭文件,pid:%d,文件名:%s,文件描述符:%d",pid,name,fd)
	FileSystem.CloseFile(fd, pid)
	Hardware.Memory.Buffer[pid][fd] = nil
	return
}

func swap(pid int, logicPageNum int) (err error){ //当前进程缺页中断，中断中给出中断页的逻辑位置，执行置换算法，调用PCB内部的Swap
	err = MemmorySystem.SwapInOut(pid, logicPageNum)
	PCBManage.Waiting(Global.MEM_DISK) //进程切换，完成所有包括PC，寄存器，runningpid的切换
	return
}

func abortProcess(pid int) (err error) { //当前进程终止
	//清理磁盘
	for _,val := range(PCBManage.PCBs[pid].PageTable)  { //malloc磁盘资源全部释放，代码保留在磁盘
		if val.Disk == -1 {
			continue
		}
		FileSystem.FreeDataBlock(val.Disk)
	}
	fmt.Print("SystemCall/磁盘清理,pid ",pid," 被清理的磁盘块 [")
	for i := len(PCBManage.PCBs[pid].PageTable) - 1 ; i >= PCBManage.PCBs[pid].CodeSiz ; i --  { //malloc磁盘资源全部释放，代码保留在磁盘
		if PCBManage.PCBs[pid].PageTable[i].Disk == -1 {
			continue
		}
		fmt.Print(PCBManage.PCBs[pid].PageTable[i].Disk," ")
		FileSystem.FreeDataBlock(PCBManage.PCBs[pid].PageTable[i].Disk)
	}
	//清理内存
	fmt.Println("]")
	err = MemmorySystem.MemoryRelease(pid)
	//关闭所有文件
	for _, val := range PCBManage.PCBs[pid].FileTable {
		FileSystem.CloseFile(val, PCBManage.PCBs[pid].PID)
		Hardware.Memory.Buffer[pid][val] = nil
	}

	Hardware.Memory.Buffer[pid] = nil
	err = PCBManage.Abort(pid)
	return
}

func installDevice(pid int, did int) {
	IO.InstructionChan <- IO.Instruction{
		IO.Install,
		did,
		pid,
		0,
		0,
		0,
		-1,
	}
}

func deviceApply(pid int, device int) (err error) {
	PCBManage.Waiting(device)
	/*
	type Instruction struct {
		Operation  int //操作
		DeviceId   int //设备号
		Pid        int //进程id
		Time       int //占用时间
		MemoryAddr int //内存地址
		BufferAddr int //外设地址
		SubType int
	}
	 */
	IO.InstructionChan <- IO.Instruction{
		IO.Apply,
		device,
		pid,
		10,
		0,
		0,
		-1,
	}
	return
}


func run(interrupt *Interrupt.Trap){
}


