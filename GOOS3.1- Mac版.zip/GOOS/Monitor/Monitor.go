package Monitor

import (
	"GOOS/Hardware"
	"GOOS/OS/PCBManage"
	"GOOS/Software"
	"encoding/json"
	"fmt"
)

type MemoryStatus struct {
	PageHolder [51]int `json:"page_holder"`
	Free       int     `json:"free"`
	Total      int     `json:"total"`
}

type QueryStatus struct {
	Pid  int `json:"pid"`
	Time int `json:"time"`
}

type DeviceStatus struct {
	DeviceID   int           `json:"device_id"`
	Status     int           `json:"status"`
	QueryQueue []QueryStatus `json:"query_queue"`
}

type ProcessStatus struct {
	RunningPid   int       `json:"running_pid"`
	ReadyQueue   []int     `json:"ready_queue"`
	WaitingQueue [10][]int `json:"waiting_queue"`
	ProcessCount int       `json:"process_count"`
}

func StartProgram(id uint64) error {
	//TODO: 调用启动程序接口
	err := Software.StartNewWork((int)(id))
	if err != nil {
		return err
	} else {
		Log(fmt.Sprintf("Start Program id=%d", id))
		return nil
	}
}

func GetProcessStatus() []byte {
	var processStatus = ProcessStatus{
		//TODO: 修改这里
		RunningPid:  PCBManage.RunningPID,
		ReadyQueue:   PCBManage.ReadyQueue,
		WaitingQueue: PCBManage.WaitingQueue,

		//=============================
		//RunningPid: 0,
		//ReadyQueue: []int{1, 2, 3, 4},
		//WaitingQueue: [10][]int{
		//	{5},
		//	{},
		//	{},
		//	{7, 8},
		//	{},
		//	{},
		//	{},
		//	{},
		//	{},
		//	{},
		//},
		//=============================
		ProcessCount: 0,
	}
	processStatus.ProcessCount = len(processStatus.ReadyQueue) + len(processStatus.WaitingQueue[0]) + len(processStatus.WaitingQueue[1]) + len(processStatus.WaitingQueue[2]) + len(processStatus.WaitingQueue[3]) + len(processStatus.WaitingQueue[4]) + len(processStatus.WaitingQueue[5]) + len(processStatus.WaitingQueue[6]) + len(processStatus.WaitingQueue[7]) + len(processStatus.WaitingQueue[8]) + len(processStatus.WaitingQueue[9])
	if processStatus.RunningPid != -1 {
		processStatus.ProcessCount++
	}
	jsonByte, err := json.Marshal(processStatus)
	if err != nil {
		Log(fmt.Sprintf("GetProcessStatus error: %s", err))
		return []byte("{\"error\": true}")
	} else {
		return jsonByte
	}
}

func GetMemoryStatus() []byte {
	memoryStatus := MemoryStatus{
		//PageHolder: [51]int{0, 1, 2, 3, 0, 4},
		//TODO: 修改这里
		PageHolder: Hardware.Memory.PageHolder,
		Free: len(Hardware.Memory.FreePages),
		//Free:  51 - 4,
		Total: 51,
	}
	jsonByte, err := json.Marshal(memoryStatus)
	if err != nil {
		Log(fmt.Sprintf("GetMemoryStatus error: %s", err.Error()))
		return []byte("\"error\": true")
	} else {
		return jsonByte
	}
}

func GetDeviceStatus() []byte {
	var deviceStatus []DeviceStatus
	//TODO: 修改这里
	//for deviceID, device := range IO.Devices {
	//	var deviceStatusItem = DeviceStatus{
	//		DeviceID:   deviceID,
	//		Status:     device.Status,
	//		QueryQueue: []QueryStatus{},
	//	}
	//	queryP := device.PidFirst
	//	for queryP != nil {
	//		deviceStatusItem.QueryQueue = append(deviceStatusItem.QueryQueue, QueryStatus{
	//			pid:  queryP.Pid,
	//			time: queryP.Time,
	//		})
	//		queryP = queryP.Next
	//	}
	//	deviceStatus = append(deviceStatus, deviceStatusItem)
	//}

	//=============================================================
	var deviceStatusItem = DeviceStatus{
		DeviceID:   1,
		Status:     1,
		QueryQueue: []QueryStatus{},
	}
	deviceStatusItem.QueryQueue = append(deviceStatusItem.QueryQueue, QueryStatus{
		Pid:  1,
		Time: 1,
	})
	deviceStatusItem.QueryQueue = append(deviceStatusItem.QueryQueue, QueryStatus{
		Pid:  2,
		Time: 2,
	})
	deviceStatus = append(deviceStatus, deviceStatusItem)
	deviceStatusItem = DeviceStatus{
		DeviceID:   2,
		Status:     1,
		QueryQueue: []QueryStatus{},
	}
	deviceStatusItem.QueryQueue = append(deviceStatusItem.QueryQueue, QueryStatus{
		Pid:  3,
		Time: 3,
	})
	deviceStatusItem.QueryQueue = append(deviceStatusItem.QueryQueue, QueryStatus{
		Pid:  4,
		Time: 4,
	})
	deviceStatus = append(deviceStatus, deviceStatusItem)
	//=============================================================
	jsonByte, err := json.Marshal(deviceStatus)
	if err != nil {
		Log(fmt.Sprintf("GetDeviceStatus error: %s", err.Error()))
		return []byte("\"error\": true")
	} else {
		return jsonByte
	}
}
