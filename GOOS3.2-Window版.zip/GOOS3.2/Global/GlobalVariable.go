package Global
//全局变量放在这
import (
	"GOOS/Interrupt"
)

var LOGS string

const ( //wait类型和IO类型
	MEM_DISK = 0 //wait磁盘
	MEM_PRINTER = 1//wait打印机


	IOREADDISK = 0 //磁盘读命令
	IOWRITEDISK = 1 //磁盘写命令
)

var BUS = make(chan Interrupt.Interrupt, 100000) //模拟中断信号总线，往里面放中断信号

var PC int //程序计数器，存储实际内存位置

var PCSave []int //程序计数器暂存，中断处理程序时候立即触发，多级中断这里使用栈实现

var SuspendReadyQueue []int //这个阻塞几乎不会发生，如果磁盘空间也不够，触发等待（不实现）

