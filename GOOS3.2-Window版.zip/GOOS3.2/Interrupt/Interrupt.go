package Interrupt

const (
	//用户接口
	USERINTERFACE = 0
//内中断 trap
	STDIN = 1 //标准输入
	STDOUT = 2 //标准输出
	NEWPROCESS = 4 //新建进程
	ABORTPROCESS = 5 //进程终止
	PAGEFAULT = 6 //缺页
	READFILE = 8 //读文件
	WRITEFILE = 9 //写文件
	MEMORYAPPLY = 10 //内存申请
	DEVICEAPPLY = 12 //设备请求
	OPENFILE = 13 //打开文件
	DELETEFILE = 15 //删除文件
	CREATEFILE = 14 //创建文件
	CLOSEFILE = 16 //关闭文件
	UNDEFINE1 = 17
	DEVICEINSTALL = 18

//外中断 interrupt
	E_STDIN = -1 //标准输入完成
	E_STDOUT = -2 //标准输出完成
	E_HARDERROR = -3 //硬件错误
	E_READFILE = -8 //读文件完成
	E_WRITEFILE = -9 //写文件完成
	E_CREATEFILE = -10 //创建文件完成
	E_PAGEFAULT = -6 //调页完成
	E_DEVICEAPPLY = -12 //设备处理完成
	E_CLOSEFILE = -13 //关闭文件完成
	E_OPENFILE = -16 //打开文件完成
	E_DISKREAD= -17 //读磁盘完成
	E_DISKWRITE= -18 //写磁盘完成
)

type Interrupt struct {
	Type int //中断类型，读/写 in out
	SubType int //子中断类型，例如如果是swap请求的磁盘读写，那么第一个Tyoe写磁盘，第二个Type写swap
	Priority int //优先级，默认0
	Pid int //请求/返回中断的进程id，就把我给你的pid原封不动返回
	Device int //什么设备返回的，磁盘操作还是打印机操作，原封不动返回deviceID
	PhysicalPageNum int //这次操作的内存页号
	PhysicalBlockNum int //这次操作的磁盘块号，这个和上面的原封不动返回 memoryADDR 和bufferADDR
	Command string //默认""
}

type Trap struct {
	Type int //类型
	Priority int //优先级
	Pid int //请求/返回中断的进程id
	//新建进程要给出的磁盘物理位置
	PhysicalDiskPage []int
	//缺页
	LogicPageNum int //处理缺页中断的缺页的逻辑页号
	//文件
	FileLogicAddress int //请求文件的逻辑位置
	FilePath string //请求文件的文件名
	FileSiz int //文件大小
	//设备
	Device int //请求设备的设备名
	//内存
	MemSiz int
	//其他
	Command string //命令号（未实现）
}
