package Hardware

type RegisterType struct { //通用寄存器组
	Axs [32]int //32个整型寄存器
}

var Registers RegisterType
