package FileSystem

var data [1024000000]byte

func readData(addr int) (result byte) {
	result = data[addr]
	return
}

func writeData(addr int, dataIn byte) {
	data[addr] = dataIn
	return
}
