<template>
  <a-space :direction="'vertical'" fill>
      <p>设备监视器</p>
      <a-list :grid-props="{ gutter: 0, span: 12 }" :bordered="false">
        <a-list-item v-for="device in devices">
          <a-list>
            <template #header>设备ID：{{device.device_id}}</template>
            <a-list-item v-for="query in device.query_queue">
              占用进程：{{query.pid}} 占用时间：{{query.time}}
            </a-list-item>
          </a-list>
        </a-list-item>
      </a-list>
  </a-space>
</template>

<script>
import axios from "axios";

export default {
    data() {
        return {
          devices: [],
          isError: false,
          intervalId: null,
        }
    },
    methods: {
        getDeviceStatus() {
          axios.get("http://localhost:2333/api/get-device-status").then(res => {
            const error = res.data.error;
            if (error != null) {
              this.isError = true;
            } else {
              this.devices = res.data;
            }
          }).catch(err => {
            this.isError = true;
          }).finally(() => {
            if(this.isError) {
              const time = new Date().toTimeString();
              this.$store.commit('setLogString', '[' + time + ']' + "failed to get device status")
              this.isError = false;
            }
          });
        }
    },
    mounted() {
      this.intervalId = setInterval(this.getDeviceStatus, 100);
    },
    unmounted() {
      clearInterval(this.intervalId);
    }
}
</script>

<style scoped>

</style>