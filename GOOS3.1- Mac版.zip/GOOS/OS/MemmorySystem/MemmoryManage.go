package MemmorySystem

import (
	"GOOS/Hardware"
	"GOOS/Interrupt"
	"GOOS/OS/FileSystem"
	"GOOS/OS/IO"
	"GOOS/OS/PCBManage"
	"fmt"
)

func Min (a int, b int) (int) {
	if a <= b {
		return a
	} else {
		return b
	}
}

func In(x int, arr *[]int) (bool) {
	for _, val := range *arr {
		if val == x {
			return true
		}
	}
	return false
}

func MemoryAllocate(pid int, siz int) (err error){
	fmt.Println("MemoryManage/申请堆栈空间，pid",pid)
	if siz > 0 { //分配堆栈
		for ; len(Hardware.Memory.FreePages) > 0 && siz > 0; siz -- {
			PCBManage.PCBs[pid].PageTable = append(PCBManage.PCBs[pid].PageTable, PCBManage.PageAtom{Hardware.Memory.FreePages[0],
				true,
				0,
				false,
				-1,
			})
			Hardware.Memory.PageHolder[Hardware.Memory.FreePages[0]] = pid
			Hardware.Memory.FreePages = Hardware.Memory.FreePages[1:]
		}
		if siz > 0 { //内存不足,请求换页
			for ; siz > 0 ;siz -- {
				PCBManage.PCBs[pid].PageTable = append(PCBManage.PCBs[pid].PageTable, PCBManage.PageAtom{
					-1,
					false,
					0,
					false,
					-1,
				})
				fmt.Println("内存不足，申请换页")
				err = SwapInOut(pid, len(PCBManage.PCBs[pid].PageTable) - 1)
			}
		}
	}
	fmt.Println("申请后新页表为\n====================================================\n内存      状态   磁盘   频率      修改")
	for _, val := range(PCBManage.PCBs[PCBManage.RunningPID].PageTable) {
		fmt.Println(val.Mem, "	 ", val.Stat, "	 ", val.Disk, " 	", val.Frequency, "	 ", val.IsChange)
	}
	fmt.Println("====================================================")
	return
}

func MemoryRelease(pid int) (err error) {
	fmt.Print("MemoryManage/内存清理,pid",pid," 被清理的内存页 [")
	for i := 0 ; i < len(PCBManage.PCBs[pid].PageTable) ; i ++ {
		page := PCBManage.PCBs[pid].PageTable[i]
		if page.Stat {
			fmt.Print(page.Mem, " ")
			Hardware.Memory.PageHolder[page.Mem] = 0
			Hardware.Memory.FreePages =  append(Hardware.Memory.FreePages, page.Mem)
			PCBManage.PCBs[pid].PageTable[i].Stat = false
		}
	}
	fmt.Println("]\n内存所有",Hardware.Memory.PageHolder)
	fmt.Println("内存状态",Hardware.Memory.PageState)
	return
}

func getPageToSwapOut(pages []int) (pid int, logicPage int) { //禁止使用page选项
	for j := 0 ; j < len(Hardware.Memory.PageHolder) * 2 ; j ++ {
		i := j % len(Hardware.Memory.PageHolder)
		if In(i, &pages) {
			continue
		}
		if Hardware.Memory.PageState[i] != 0 {
			continue
		}
		if Hardware.Memory.PageClock[i] == 0 {
			Hardware.Memory.PageClock[i] = 1
		} else {
			pid = Hardware.Memory.PageHolder[i]
			logicPage, _ = PCBManage.PCBs[pid].LogicPC(i * 1024)
			logicPage /= 1024
			Hardware.Memory.PageClock[i] = 0
			return
		}
	}
	return
}

func SwapInOut(pid int, logicPage int) (err error) { //内存换入换出 要换进来的pid和逻辑页面
	fmt.Print("MemoryManage/换页处理,pid ",pid," 逻辑内存页号 ",logicPage," 物理内存页号(-1表示未分配) ",PCBManage.PCBs[pid].PageTable[logicPage].Mem," ")
	if PCBManage.PCBs[pid].PageTable[logicPage].Stat {
		return
	}
	//找到一个合理的磁盘空间,当前进程的当前页面永远不会被换出，所有正在执行读写命令的页面不会被换出，也就是对应下面为state为1 2 的
	/*
	type MemoryType struct {
		PageHolder [1024*1024]int
		FreePages []int
		PageState [1024*1024]int //三种state，一种正在读1，一种正在写2，一种未处理0
	}

	type PageAtom struct {
		Mem int
		Stat bool
		Frequency int
		IsChange bool
		Disk int //-1代表无对应磁盘
	}
	*/
	physicalPage := PCBManage.PCBs[pid].PageTable[logicPage].Disk //得到换入页的物理地址
	if physicalPage == -1 {
		//缺一个物理页是-1的不算缺页，不予分配内存，只会分配给它一个磁盘
		block := FileSystem.GetDataBlock()                     //申请一块磁盘空间
		fmt.Println("申请的物理页过多，不予分配，但是会申请新的磁盘块",block,"给这个页")
		PCBManage.PCBs[pid].PageTable[logicPage].Disk = block
		return
	}
	/*
		type Instruction struct {
			Operation  int //操作
			DeviceId   int //设备号
			Pid        int //进程id
			Time       int //占用时间
			MemoryAddr int //内存地址
			BufferAddr int //外设地址
			SubType int
		}
	in是磁盘到内存，out是内存到磁盘
	*/

	if len(Hardware.Memory.FreePages) != 0 { //=============================================================================================内存充足，只需要swap in
		page := Hardware.Memory.FreePages[0] //找一个空闲物理页page
		Hardware.Memory.PageState[page] = 2 //这页要进行IO写，限制操作,其他进程不能被访问
		PCBManage.PCBs[pid].PageTable[logicPage].Mem = page
		Hardware.Memory.FreePages = Hardware.Memory.FreePages[1:]

		fmt.Println("内存充足，分配空闲块",page)

		IO.InstructionChan <- IO.Instruction{
			IO.In,
			0,
			pid,
			3,
			page,
			physicalPage,
			Interrupt.E_PAGEFAULT,
		}
		return
	}

	//===================================================================================================================================内存不够，需要swap out swap in

	pid2, logicpage := getPageToSwapOut([]int{0})          //拿到一个合理换出进程的合理逻辑块号
	page := PCBManage.PCBs[pid2].PageTable[logicpage].Mem //得到要交换出去的物理页page
	Hardware.Memory.PageState[page] = 1                   //这页要进行IO读，限制操作,其他进程不能被访问
	Hardware.Memory.PageHolder[page] = 0                 //此时这页没有主人，处于换入换出状态
	fmt.Print("内存不足，找到的换出的pid ",pid2," 物理页 ",page," ")
	//swap out
	PCBManage.PCBs[pid2].PageTable[logicpage].Stat = false

	if PCBManage.PCBs[pid2].PageTable[logicpage].Disk == -1 { //未被分配磁盘空间
		block := FileSystem.GetDataBlock()                     //申请一块磁盘空间
		fmt.Println("在pageTable中没有磁盘位置，申请新的磁盘块",block)
		PCBManage.PCBs[pid2].PageTable[logicpage].Disk = block //修改page table
		IO.InstructionChan <- IO.Instruction{
			IO.Out,
			0,
			pid2,
			3,
			page,
			block,
			Interrupt.E_PAGEFAULT,
		}
	} else {                                                    //有磁盘空间了,直接放到磁盘空间就行
		fmt.Println("在pageTable中有磁盘映射",PCBManage.PCBs[pid2].PageTable[logicpage].Disk)
		if PCBManage.PCBs[pid2].PageTable[logicpage].IsChange { //内容发生了改变才会修改磁盘
			IO.InstructionChan <- IO.Instruction{
				IO.Out,
				0,
				pid2,
				3,
				page,
				PCBManage.PCBs[pid2].PageTable[logicpage].Disk,
				Interrupt.E_PAGEFAULT,
			}
		}
	}

	// swap in
	PCBManage.PCBs[pid].PageTable[logicPage].Mem = page
	IO.InstructionChan <- IO.Instruction{
		IO.In,
		0,
		pid,
		3,
		page,
		physicalPage,
		Interrupt.E_PAGEFAULT,
	}
	fmt.Println("内存所有",Hardware.Memory.PageHolder)
	fmt.Println("内存状态",Hardware.Memory.PageState)

	return
}