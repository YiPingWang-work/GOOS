package main

import (
	"GOOS/Monitor"
	"net/http"
	"os"
	"strconv"
)

func Handler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	query := r.URL.Query()
	switch r.URL.Path {
	case "/api/get-process-status":
		{
			data := Monitor.GetProcessStatus()
			w.Write(data)
			return
		}
	case "/api/get-memory-status":
		{
			data := Monitor.GetMemoryStatus()
			w.Write(data)
			return
		}
	case "/api/get-device-status":
		{
			data := Monitor.GetDeviceStatus()
			w.Write(data)
			return
		}
	case "/api/start-program":
		{
			programId := query.Get("id")
			if programId == "" {
				w.Write([]byte("{\"error\":\"no program id\"}"))
				return
			}
			id, _ := strconv.Atoi(programId)
			err := Monitor.StartProgram(uint64(id))
			if err != nil {
				w.Write([]byte("{\"error\":\"" + err.Error() + "\"}"))
				return
			} else {
				w.Write([]byte("{\"error\":null}"))
				return
			}
		}
	}
}

func Server(port uint64) {
	http.HandleFunc("/api/", Handler)
	http.Handle("/", http.FileServer(http.Dir("static/dist")))
	err := http.ListenAndServe(":"+strconv.FormatUint(port, 10), nil)
	if err != nil {
		os.Exit(1)
	}
	wg.Done()
}
