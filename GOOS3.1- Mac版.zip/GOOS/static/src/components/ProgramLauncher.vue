<template>
  <a-space :direction="'vertical'" fill>
    <p>程序启动器</p>
    <a-space>
      <a-button v-for="item of programs" type="outline" class="app-button" :loading="item.isLoading" @click="onAppClick(item)">
        <template #icon>
          <icon-apps size="32"/>
        </template>
        <template #default>
          <br>
          {{ item.name }}
        </template>
      </a-button>
    </a-space>
  </a-space>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      programs: [
        {
          name: 'App0',
          id: 0,
          isLoading: false,
        },
        {
          name: 'App1',
          id: 1,
          isLoading: false,
        },
        {
          name: 'App2',
          id: 2,
          isLoading: false,
        },
      ],
      isError: false,
    }
  },
  methods: {
    onAppClick(app) {
      app.isLoading = true;
      const res = this.startProgram(app.id);
      if(res) {
        this.$message.success('start program ' + app.name);
      }
      app.isLoading = false;
    },
    startProgram(program) {
      axios.get("http://localhost:2333/api/start-program", {
        params: {
          "id": program
        }
      }).then(res => {
        const error = res.data.error;
        if(error != null) {
          this.isError = true;
          console.log(error);
        }
      }).catch(err => {
        this.isError = true;
      });
      if(this.isError) {
        const time = new Date().toTimeString();
        this.$store.commit('setLogString', '[' + time + ']' + "failed to start program id=" + program)
        console.log(this.$store.state.LogString)
        this.isError = false;
        return false;
      } else {
        const time = new Date().toTimeString();
        this.$store.commit('setLogString', '[' + time + ']' + "started program id=" + program)
        console.log(this.$store.state.LogString)
        return true;
      }
    },
  }
}
</script>

<style scoped>
.app-button {
  width: 100px;
  height: 100px;
  border-radius: 10%;
}
</style>