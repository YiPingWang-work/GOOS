package Process

//处理外部中断
import (
	"GOOS/Global"
	"GOOS/Hardware"
	"GOOS/Interrupt"
	"GOOS/OS/IO"
	"GOOS/OS/PCBManage"
	"errors"
	"fmt"
)

/*
type Interrupt struct {
	Type int //中断类型，读/写 in out
	SubType int //子中断类型，例如如果是swap请求的磁盘读写，那么第一个Tyoe写磁盘，第二个Type写swap
	Priority int //优先级，默认0
	Pid int //请求/返回中断的进程id，就把我给你的pid原封不动返回
	Device int //什么设备返回的，磁盘操作还是打印机操作，原封不动返回deviceID
	PhysicalPageNum int //这次操作的内存页号
	PhysicalBlockNum int //这次操作的磁盘块号，这个和上面的原封不动返回 memoryADDR 和bufferADDR
	Command string //默认""
}
*/
func INTExecute(interrupt *Interrupt.Interrupt) (err error) {
	pid := interrupt.Pid
	switch interrupt.Type {
	case Interrupt.E_STDIN:

	case Interrupt.E_STDOUT:

	case Interrupt.E_READFILE:
		err = finishReadFile(pid, interrupt.SubType)
	case Interrupt.E_WRITEFILE:
		err = finishWriteFile(pid, interrupt.SubType)
	case IO.In:
		if interrupt.SubType == Interrupt.E_PAGEFAULT { //换页的swap in结束，整个换页结束
			err = finishSwapRead(pid, interrupt.PhysicalPageNum)
		} else { //普通读磁盘操作
			err = finishReadDisk(pid, interrupt.PhysicalPageNum)
		}
	case IO.Apply:
		err = finishDevice(pid, interrupt.Device)
	case IO.Out:
		if interrupt.SubType == Interrupt.E_PAGEFAULT { //是换页的中间的swap out操作
			err = finishSwapWrite(pid, interrupt.PhysicalPageNum)
		} else { //普通写磁盘操作
			err = finishWriteDisk(pid, interrupt.PhysicalBlockNum)
		}
	default:
		err = errors.New("interrupt error")

	}
	return
}

func finishReadFile(pid int, fd int) (err error) {
	fmt.Println("INITExecute/读文件返回", pid, "文件描述符", fd)
	fmt.Println("此时该文件已经读到的所有内容为", string(Hardware.Memory.Buffer[pid][fd]))
	Global.LOGS = fmt.Sprintf("INITExecute/读文件返回,pid:%d,文件描述符:%d,此时对于该文件全部读到的内容:%s", pid, fd, string(Hardware.Memory.Buffer[pid][fd]))
	err = PCBManage.Awake(pid, Global.MEM_DISK)
	return
}

func finishWriteFile(pid int, fd int) (err error) {
	fmt.Println("INITExecute/写文件返回", pid, "文件描述符", fd)
	Global.LOGS = fmt.Sprintf("INITExecute/写文件返回,pid:%d,文件描述符:%d", pid, fd)
	err = PCBManage.Awake(pid, Global.MEM_DISK)
	return
}

func finishSwapRead(pid int, physicalPage int) (err error) { //交换返回，swap in完成，整个swap inout完成，结束
	fmt.Println("INITExexute/缺页交换swapin完成，pid是", pid, "物理页是", physicalPage)
	Global.LOGS = fmt.Sprintf("INITExexute/缺页交换swapin完成，pid:%d,物理页:%d", pid, physicalPage)
	Hardware.Memory.PageState[physicalPage] = 0               //这一页允许读写
	Hardware.Memory.PageHolder[physicalPage] = pid            //这一页的进程所有者确定
	PCBManage.PCBs[PCBManage.RunningPID].IsPageFault = false  //这个进程不再缺页
	Hardware.Memory.PageClock[physicalPage] = 0               //设置clock
	for i := 0; i < len(PCBManage.PCBs[pid].PageTable); i++ { //修改这个进程的页表
		if PCBManage.PCBs[pid].PageTable[i].Mem == physicalPage {
			PCBManage.PCBs[pid].PageTable[i].Stat = true      //在内存中
			PCBManage.PCBs[pid].PageTable[i].IsChange = false //新换进来的没有被修改
			fmt.Println(PCBManage.PCBs[pid].PC, i)
			PCBManage.PCBs[pid].PC++
			PCBManage.PCBs[pid].Flag = true
			break
		}
	}
	err = PCBManage.Awake(pid, Global.MEM_DISK) //唤醒这个进程
	fmt.Println("内存所有", Hardware.Memory.PageHolder)
	fmt.Println("内存状态", Hardware.Memory.PageState)
	fmt.Println("交换返回后页表\n====================================================\n内存      状态   磁盘   频率      修改")
	for _, val := range PCBManage.PCBs[pid].PageTable {
		fmt.Println(val.Mem, "	 ", val.Stat, "	", val.Disk, " 	", val.Frequency, "	 ", val.IsChange)
	}
	fmt.Println("====================================================")
	return
}

func finishReadDisk(pid int, physicalPage int) (err error) {
	Hardware.Memory.PageState[physicalPage] = 0
	err = PCBManage.Awake(pid, Global.MEM_DISK)
	return
}

func finishSwapWrite(pid int, physicalPage int) (err error) { //交换返回，swap out完成现在开始读磁盘的文件
	fmt.Println("INITExecute/缺页交换swapout完成，swapOut的pid是", pid, "物理页是", physicalPage)
	Global.LOGS = fmt.Sprintf("INITExexute/缺页交换swapout完成，pid:%d,物理页:%d", pid, physicalPage)
	Hardware.Memory.PageState[physicalPage] = 2
	fmt.Println("内存所有", Hardware.Memory.PageHolder)
	fmt.Println("内存状态", Hardware.Memory.PageState)
	return
}

func finishWriteDisk(pid int, physicalPage int) (err error) {
	Hardware.Memory.PageState[physicalPage] = 0
	err = PCBManage.Awake(pid, Global.MEM_DISK)
	return
}

func finishDevice(pid int, device int) (err error) {
	fmt.Println("INITExecute/设备使用完返回", pid)
	err = PCBManage.Awake(pid, device)
	return
}
