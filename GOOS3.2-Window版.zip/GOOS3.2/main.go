package main

import (
	"GOOS/Global"
	"GOOS/Hardware"
	"GOOS/Monitor"
	"GOOS/OS/FileSystem"
	"GOOS/OS/IO"
	"GOOS/OS/PCBManage"
	"GOOS/Software"
	"fmt"
	"sync"
	"time"
)

var wg sync.WaitGroup

/*
发现的问题
文件第二次读操作失败（两个进程之间）
 */


func LoadBoot() {
	//初始化
	go IO.StartDevice() //初始化设备并开启DMA模式
	FileSystem.Initialize() //初始化文件系统
	fmt.Println("初始化.....")
	time.Sleep(time.Second)
	fmt.Println("初始完成.....")
	Global.PC = -1 //设置当前PC值（PC先+在取指令）
	PCBManage.RunningPID = 1 //加载1号进程
	for i := 1 ; i < 51 ; i ++ { //初始化空闲页表
		Hardware.Memory.FreePages = append(Hardware.Memory.FreePages, i)
	}
	Hardware.Memory.PageHolder[0] = 1

	//初始化1号进程
	PCBManage.PCBs[1].PID = 1
	PCBManage.PCBs[1].Allocated = true
	PCBManage.PCBs[1].Ppid = 0
	PCBManage.PCBs[1].PageTable = append(PCBManage.PCBs[1].PageTable, PCBManage.PageAtom{
		0,
		true,
		0,
		false,
		-1,
	})
	Hardware.Memory.Page[0][15] = "loop|15"
	ostime, cnt := Software.OS_init()
	Ostime = ostime
	Cnt = cnt
}

func iiiii() {
	Monitor.CreateLog()
	wg.Add(1)
	go Server(2333)
	wg.Wait()
}

func main() {
	LoadBoot()
	go iiiii()
	Run()
}


