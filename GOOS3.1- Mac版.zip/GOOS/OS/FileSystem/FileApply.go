package FileSystem

import (
	"GOOS/OS/IO"
	"strings"
)

//文件系统

// Block 块
type Block struct {
	Data [1024]byte
}

func writeBlock(addr int, block Block) {
	i := 0
	for i < len(block.Data) {
		writeData(addr+i, block.Data[i])
		i++
	}
}

func readBlock(addr int) (result Block) {
	i := 0
	for i < len(result.Data) {
		result.Data[i] = readData(addr + i)
		i++
	}
	return
}

// SuperBlock 超级块
type SuperBlock struct {
	blockSize  int //块大小
	bitMap     int //位图首地址
	bitMapSize int //位图大小，也就是整个文件系统分区大小
	iNode      int //iNode区首地址，默认第一个iNode存储根目录文件
	data       int //数据块区首地址
}

func superBlockToBlock(superBlock SuperBlock) (block Block) {
	return
}

// INode 节点
type INode struct {
	fileType int      //文件类型
	mode     int      //模式
	size     int      //文件大小
	index    [256]int //直接地址
	iIndex   [2]int   //一级索引
	//iiIndex  [1]int   //两级索引
}

// Directory 目录
type Directory struct {
	name     string
	subDir   map[string]*Directory
	subFiles map[string]int
}

var superBlock SuperBlock
var INodeBitMap [1000]bool
var DataBitMap [1000000]bool
var RootDir *Directory
var INodes [1000]INode
var DataBlock [1000000]Block
var OpenFileTable map[int]*File

// Initialize 文件系统初始化
func Initialize() {
	//读取超级块
	superBlock.blockSize = 1024

	//读取目录
	RootDir = new(Directory)
	RootDir.subDir = make(map[string]*Directory)
	RootDir.subFiles = make(map[string]int)

	//初始化变量
	OpenFileTable = make(map[int]*File)

	return
}

// Format 格式化硬盘，建立文件系统
func Format() {
	////读取硬盘容量
	//diskSize := len(Data)
	//
	////划分存储区域：交换区、超级块、INodes、Data
	//sbAddr := int(float64(diskSize) * 0.1)
	//iNodeAddr := sbAddr + 1
	//dataAddr := iNodeAddr + sbAddr
	//
	////写入超级块
	//sb := SuperBlock{}
	//sb.iNodeSize = 1024
	//sb.blockSize = 1024
	//sb.INodes = iNodeAddr
	//sb.Data = dataAddr
	//sb.bitMap[0] = true
	//
	//writeOneBlock(sbAddr, sb)

	//写入根目录
	//rootDirFile := INode{}
	//rootDirFile.fileType = 0
	//rootDirFile.

	return
}

func GetFileSystemInfo() (superBlockR SuperBlock, iNodeBitMapR [1000]bool, dataBitMapR [1000000]bool,
	rootDirR *Directory, iNodeR [1000]INode, dataBlockR [1000000]Block, openFileTableR map[int]*File) {
	superBlockR = superBlock
	iNodeBitMapR = INodeBitMap
	dataBitMapR = DataBitMap
	rootDirR = RootDir
	iNodeR = INodes
	dataBlockR = DataBlock
	openFileTableR = OpenFileTable
	return
}

//--------------------------目录--------------------------//

//目录定位
func locateDirectory(path string) (directory *Directory, newDirTokens []string) {
	dirTokens := strings.Split(path, "/")
	currentDir := RootDir
	currentToken := 0
	for _, i := range dirTokens {
		if i == "" {
			currentToken++
			continue
		}
		subDir := currentDir.subDir[i]
		if subDir == nil {
			break
		}
		currentDir = subDir
		currentToken++
	}
	directory = currentDir
	newDirTokens = dirTokens[currentToken:]
	return
}

// CreateDirectoryByPath 新建目录
func CreateDirectoryByPath(path string) {
	//定位已有目录
	currentDir, newDirTokens := locateDirectory(path)

	//新建目录文件
	for _, i := range newDirTokens {
		if i == "" {
			continue
		}
		newDir := new(Directory)
		newDir.subDir = make(map[string]*Directory)
		newDir.subFiles = make(map[string]int)
		currentDir.subDir[i] = newDir
		currentDir = newDir
		currentDir.name = i
	}

	return
}

// DeleteDirectoryByPath 删除目录
func DeleteDirectoryByPath(path string) {
	//定位已有目录
	currentDir, newDirTokens := locateDirectory(path)

	if len(newDirTokens) != 0 {
		return
	}

	deleteDirectory(currentDir)

	return
}

func deleteDirectory(dir *Directory) {
	//检测目录下是否有子目录，有则递归删除
	for _, v := range dir.subDir {
		deleteDirectory(v)
	}
	for _, v := range dir.subFiles {
		deleteFile(v)
	}
}

//------------------------文件---------------------------//

//文件定位
func locateFile(path string) (file int, fileName string, fileDir *Directory) {
	//拆分路径
	dirTokens := strings.Split(path, "/")
	//定位路径
	fileName = dirTokens[len(dirTokens)-1]
	dirTokens = dirTokens[:len(dirTokens)-1]
	fileDir = RootDir
	for _, i := range dirTokens {
		if i == "" {
			continue
		}
		subDir, isExist := fileDir.subDir[i]
		if !isExist {
			fileDir = nil
			break
		}
		fileDir = subDir
	}
	//检查路径是否正常
	if fileDir == nil {
		return -1, "", nil
	}
	//检查文件是否存在
	file, isExist := fileDir.subFiles[fileName]
	if !isExist {
		return -1, "", nil
	}

	return
}

// CreateFileByPath 新建文件
func CreateFileByPath(path string, fileType int) {
	//判断空闲iNode是否足够
	currentINode := 0
	for currentINode < len(INodeBitMap) {
		if INodeBitMap[currentINode] == false {
			break
		}
		currentINode++
	}
	if currentINode == len(INodeBitMap) {
		return
	}

	//定位到指定目录
	currentDir, newDirTokens := locateDirectory(path)

	//目录不存在，返回
	if len(newDirTokens) != 1 {
		return
	}

	//判断目录文件是否有空间添加新文件
	//若无法新增，返回错误

	//占用iNode
	INodeBitMap[currentINode] = true

	//将文件信息写入iNode
	INodes[currentINode].size = 0
	INodes[currentINode].fileType = fileType

	//将文件信息写入目录
	currentDir.subFiles[newDirTokens[0]] = currentINode

	return
}

// MoveFile 移动文件
func MoveFile(oldPath, newPath string) {
	//定位至源目录
	file, fileName, fileDir := locateFile(oldPath)
	if file == -1 {
		return
	}

	//定位至目的目录
	currentDirNew, newDirTokensNew := locateDirectory(newPath)
	if len(newDirTokensNew) != 0 {
		return
	}

	//检查新目录文件是否有足够空间存放新的条目

	//将被移动目录地址写入新目录文件
	currentDirNew.subFiles[fileName] = file

	//抹除源目录中的对应记录
	delete(fileDir.subFiles, fileName)

	return
}

// DeleteFileByPath 删除文件
func DeleteFileByPath(path string) {
	//定位至iNode
	currentINode, fileName, fileDir := locateFile(path)
	if currentINode == -1 || currentINode > len(INodes) {
		return
	}

	//检查文件是否被打开
	//for _, i := range Global.OpenFileTable{
	//	if i.addr == currentINode{
	//		return
	//	}
	//}
	for _, i := range OpenFileTable {
		if i.iNode == currentINode {
			return
		}
	}

	//目录中清除记录
	fileDir.subFiles[fileName] = -1

	deleteFile(currentINode)

	return
}

//删除文件
func deleteFile(addr int) {
	clearFile(addr)

	//修改iNode对应位图，标记为空闲
	INodeBitMap[addr] = false
}

//清空文件
func clearFile(addr int) {
	//修改对应数据块的位图，标记为空闲
	for _, i := range INodes[addr].index {
		DataBitMap[i] = false
	}
	for _, i := range INodes[addr].iIndex {
		index := blockToIndex(DataBlock[i])
		for _, j := range index {
			DataBitMap[j] = false
		}
		DataBitMap[i] = false
	}
	//for _, i := range INodes[addr].iiIndex {
	//	iIndex := blockToIndex(DataBlock[i])
	//	for _, j := range iIndex {
	//		index := blockToIndex(DataBlock[j])
	//		for _, k := range index {
	//			DataBitMap[k] = false
	//		}
	//		DataBitMap[j] = false
	//	}
	//	DataBitMap[i] = false
	//}

	//修改iNode信息，包括索引指针、文件大小等
	INodes[addr].size = 0
	for i := 0; i < len(INodes[addr].index); i++ {
		INodes[addr].index[i] = -1
	}
	for i := 0; i < len(INodes[addr].iIndex); i++ {
		INodes[addr].iIndex[i] = -1
	}
	//for i:=0; i < len(INodes[addr].iiIndex);i++ {
	//	INodes[addr].iiIndex[i] = -1
	//	i++
	//}
	return
}

//生成索引块，小端方式
func indexToBlock(index []int) (block Block) {
	if len(index) > 256 {
		return
	}
	currentAddr := 0
	for _, i := range index {
		block.Data[currentAddr] = byte(i)
		currentAddr++
		block.Data[currentAddr] = byte(i >> 4)
		currentAddr++
		block.Data[currentAddr] = byte(i >> 8)
		currentAddr++
		block.Data[currentAddr] = byte(i >> 12)
		currentAddr++
	}
	end := -1
	block.Data[currentAddr] = byte(end)
	currentAddr++
	block.Data[currentAddr] = byte(end >> 4)
	currentAddr++
	block.Data[currentAddr] = byte(end >> 8)
	currentAddr++
	block.Data[currentAddr] = byte(end >> 12)
	currentAddr++
	return
}

//解析索引块
func blockToIndex(block Block) (index []int) {
	currentAddr := 0
	for currentAddr < len(block.Data) {
		currentIndex := int(block.Data[currentAddr])
		currentAddr++
		currentIndex += int(block.Data[currentAddr]) << 4
		currentAddr++
		currentIndex += int(block.Data[currentAddr]) << 8
		currentAddr++
		currentIndex += int(block.Data[currentAddr]) << 12
		currentAddr++
		if currentIndex == -1 {
			break
		}
		index = append(index, currentIndex)
	}
	return
}

// File 打开文件对象
type File struct {
	name     string
	iNode    int
	fileType int          //文件类型
	mode     int          //模式
	size     int          //文件大小
	count    int          //占用计数
	pid      map[int]bool //占用进程

	//以下内容当文件为设备映射时使用
	deviceId int //设备号
}

// OpenFileByPath 打开文件
func OpenFileByPath(path string, pid int) (fileAddr int) {
	//定位到指定目录
	fileINode, fileName, _ := locateFile(path)

	//检查文件是否已被打开
	file, isExist := OpenFileTable[fileINode]

	if isExist {
		file.pid[pid] = true
		file.count++
		return fileINode
	}
	//读取iNode信息，打开文件表新建项
	fileInfo := INodes[fileINode]
	file = new(File)
	file.name = fileName
	file.fileType = fileInfo.fileType
	file.size = fileInfo.size
	file.mode = fileInfo.mode
	file.pid = make(map[int]bool)
	file.pid[pid] = true
	file.count = 1
	file.iNode = fileINode

	OpenFileTable[fileINode] = file

	//返回打开文件表中对应项地址
	fileAddr = fileINode

	return
}

// CloseFile 关闭文件
func CloseFile(fileAddr int, pid int) {
	//判断文件是否存在
	file, isExist := OpenFileTable[fileAddr]
	if !isExist {
		return
	}
	//判断pid表中是否存在对应表项
	_, isExist = file.pid[pid]
	if !isExist {
		return
	}
	//从pid表中移除对应项
	delete(file.pid, pid)
	//文件打开计数--
	file.count--
	//如果为最后一个
	if file.count == 0 {
		delete(OpenFileTable, fileAddr)
	}

	return
}

// GetDataBlock 获取一个空闲块
func GetDataBlock() (block int) {
	for i := 0; i < len(DataBitMap); i++ {
		if !DataBitMap[i] {
			DataBitMap[i] = true
			return i
		}
	}
	return -1
}

// FreeDataBlock 释放一个块
func FreeDataBlock(block int) {
	DataBitMap[block] = false
}

// ChangeFileSize 修改文件大小
func ChangeFileSize(fileAddr int, size int) (ok bool) {
	file := OpenFileTable[fileAddr]

	if file.size == size {
		return true
	}
	//找到对应iNode
	fileINode := &INodes[file.iNode]
	//计算新文件占用的数据块数量
	newBlockSize := size / superBlock.blockSize
	if size%superBlock.blockSize != 0 {
		newBlockSize++
	}
	//计算旧文件占用的数据块数量
	oldBlockSize := file.size / superBlock.blockSize
	if file.size%superBlock.blockSize != 0 {
		oldBlockSize++
	}
	//缩小文件
	if size < file.size {
		//如果新大小在直接地址表示范围内
		if newBlockSize < len(fileINode.index) {
			//清除直接地址对应块
			for i := newBlockSize; i < oldBlockSize; i++ {
				DataBitMap[fileINode.index[i]] = false
				fileINode.index[i] = -1
			}
			//清除一级间址对应块
			for i := 0; i < len(fileINode.iIndex); i++ {
				if fileINode.iIndex[i] == -1 {
					break
				}
				index := blockToIndex(DataBlock[fileINode.iIndex[i]])
				for _, j := range index {
					if j == -1 {
						break
					}
					DataBitMap[j] = false
				}
				DataBitMap[fileINode.iIndex[i]] = false
				fileINode.iIndex[i] = -1
			}
		} else {
			newBlockSize -= len(fileINode.index)
			indexSize := (newBlockSize / (superBlock.blockSize / 4)) + 1
			//清除文件末尾索引块中的多余表项
			lastIndex := blockToIndex(DataBlock[fileINode.iIndex[indexSize]])
			for i := (newBlockSize % (superBlock.blockSize / 4)) + 1; i < len(lastIndex); i++ {
				DataBitMap[lastIndex[i]] = false
				lastIndex[i] = -1
			}
			DataBlock[fileINode.iIndex[indexSize]] = indexToBlock(lastIndex)
			//清除剩余一级间址对应块
			for i := indexSize + 1; i < len(fileINode.iIndex); i++ {
				if fileINode.iIndex[i] == -1 {
					break
				}
				index := blockToIndex(DataBlock[fileINode.iIndex[i]])
				for _, j := range index {
					if j == -1 {
						break
					}
					DataBitMap[j] = false
				}
				DataBitMap[fileINode.iIndex[i]] = false
				fileINode.iIndex[i] = -1
			}
		}
		ok = true
	} else {
		//扩大文件
		//计算差值
		diff := newBlockSize - oldBlockSize
		//原文件大小可以用直接索引表示
		if oldBlockSize < len(fileINode.index) {
			//直接地址申请块
			for i := oldBlockSize + 1; i < len(fileINode.index) && diff > 0; i++ {
				fileINode.index[i] = GetDataBlock()
				diff--
			}
			//间接地址申请块
			for i := 0; i < len(fileINode.iIndex) && diff > 0; i++ {
				//申请索引块
				fileINode.iIndex[i] = GetDataBlock()
				indexes := blockToIndex(DataBlock[fileINode.iIndex[i]])
				//申请数据块
				for j := 0; j < len(indexes) && diff > 0; j++ {
					indexes[j] = GetDataBlock()
					diff--
				}
				DataBlock[fileINode.iIndex[i]] = indexToBlock(indexes)
			}
		} else {
			oldBlockSize -= len(fileINode.index)
			//找到文件末尾二级间址
			iIndex := oldBlockSize / (superBlock.blockSize / 4)
			//找到文件末尾二级间址内部地址
			iIndexEnd := oldBlockSize % (superBlock.blockSize / 4)
			//从文件末尾开始申请数据块直至符合新文件大小
			//填充文件末尾处索引块
			indexes := blockToIndex(DataBlock[fileINode.iIndex[iIndex]])
			for j := iIndexEnd + 1; j < len(indexes) && diff > 0; j++ {
				indexes[j] = GetDataBlock()
				diff--
			}
			//不够则申请新的索引块
			for i := iIndex + 1; i < len(fileINode.iIndex) && diff > 0; i++ {
				fileINode.iIndex[i] = GetDataBlock()
				indexesNew := blockToIndex(DataBlock[fileINode.iIndex[i]])
				for j := 0; j < len(indexesNew) && diff > 0; j++ {
					indexesNew[j] = GetDataBlock()
					diff--
				}
			}
		}
	}
	file.size = size
	fileINode.size = size
	return
}

//定位所需数据块，若超出当前或剩余空间不足则返回nil
func locateDataBlock(file *File, addr int) (block int) {
	if addr >= file.size {
		//ok := ChangeFileSize(file, addr)
		//if !ok {
		//	return -1
		//}
		return -1
	}
	fileINode := &INodes[file.iNode]
	//定位到文件中指定地址
	//计算块地址值
	blockAddr := addr / superBlock.blockSize
	//直接地址
	if blockAddr < len(fileINode.index) {
		block = fileINode.index[addr]
		return
	}
	//一级间址
	blockAddr -= len(fileINode.index)
	indexBlockSize := superBlock.blockSize / 4
	if blockAddr < len(fileINode.iIndex)*indexBlockSize {
		indexAddr := blockAddr / indexBlockSize
		index := blockToIndex(DataBlock[fileINode.iIndex[indexAddr]])
		block = index[blockAddr%indexBlockSize]
		return
	}
	//二级间址
	//blockAddr -= len(fileINode.iIndex) * indexBlockSize
	//iIndexBlockSize := indexBlockSize * indexBlockSize
	//if blockAddr < len(fileINode.iiIndex)*iIndexBlockSize {
	//	iIndexAddr := blockAddr / iIndexBlockSize
	//	iIndex := blockToIndex(DataBlock[fileINode.iiIndex[iIndexAddr]])
	//	blockAddr = blockAddr % iIndexBlockSize
	//	indexAddr := blockAddr / indexBlockSize
	//	index := blockToIndex(DataBlock[iIndex[indexAddr]])
	//	block = index[blockAddr%indexBlockSize]
	//} else {
	//	return -1
	//}
	return
}

// WriteFile 写文件
func WriteFile(fileAddr int, addr int, data []byte, pid int) {
	ioInstruction := IO.Instruction{
		Operation:  IO.WriteFile,
		DeviceId:   0,
		Pid:        pid,
		Time:       1,
		MemoryAddr: 0,
		BufferAddr: 0,
		SubType:    fileAddr,
	}
	IO.InstructionChan <- ioInstruction

	file := OpenFileTable[fileAddr]

	//修改文件大小以适应写入
	if file.size < addr+len(data) {
		ChangeFileSize(fileAddr, addr+len(data))
	}

	//定位到文件中指定块
	var blocks []int
	endAddr := addr + (len(data) / superBlock.blockSize)

	for i := addr; i <= endAddr; i++ {
		block := locateDataBlock(file, i)
		if block == -1 {
			blocks = nil
			break
		}
		blocks = append(blocks, block)
	}

	if blocks == nil {
		return
	}

	//写入数据
	dataIndex := 0
	blockIndex := 0
	for dataIndex < len(data) && blockIndex < len(blocks) {
		for i := 0; dataIndex < len(data) && i < superBlock.blockSize; i++ {
			DataBlock[blocks[blockIndex]].Data[i] = data[dataIndex]
			dataIndex++
		}
		blockIndex++
	}

	return
}

// ReadFile 读文件
func ReadFile(fileAddr int, addr int, size int, pid int) (data []byte) {
	ioInstruction := IO.Instruction{
		Operation:  IO.ReadFile,
		DeviceId:   0,
		Pid:        pid,
		Time:       1,
		MemoryAddr: 0,
		BufferAddr: 0,
		SubType:    fileAddr,
	}
	IO.InstructionChan <- ioInstruction

	file := OpenFileTable[fileAddr]

	//检查是否超出文件范围
	if addr+size >= file.size || size < 0 {
		return nil
	}

	//定位到文件中指定块
	var blocks []int
	endAddr := addr + (len(data) / superBlock.blockSize)

	for i := addr / superBlock.blockSize; i <= endAddr; i++ {
		block := locateDataBlock(file, i)
		if block == -1 {
			blocks = nil
			break
		}
		blocks = append(blocks, block)
	}

	if blocks == nil {
		return
	}

	//读出数据
	for k, i := range blocks {
		if k == 0 {
			for j := addr % superBlock.blockSize; j < superBlock.blockSize; j++ {
				data = append(data, DataBlock[blocks[i]].Data[j])
				if len(data) >= size {
					return
				}
			}
		}
		for _, j := range DataBlock[blocks[i]].Data {
			data = append(data, j)
			if len(data) >= size {
				return
			}
		}
	}

	return
}
