<template>
  <a-space :direction="'vertical'" fill>
    <p>内存监视器</p>
    <a-space :direction="'horizontal'">
      <a v-for="stat in memStat" v-bind:class="{'stat-item': true, 'active': (stat === 0)}">{{stat}}</a>
    </a-space>
    <a-space size="large">
      <a-statistic title="Free" :value="free"></a-statistic>
      <a-statistic title="Total" :value="total"></a-statistic>
    </a-space>
  </a-space>
</template>

<script>
import axios from "axios";
export default {
  data() {
    return {
      memStat: [],
      free: 1024,
      total: 2048,
      isError: false,
      intervalId: null
    }
  },
  methods: {
    getMemStat() {
      axios.get('http://localhost:2333/api/get-memory-status').then(res => {
        const error = res.data.error
        if(error != null) {
          this.isError = true
        } else {
          this.memStat = res.data.page_holder
          this.free = res.data.free
          this.total = res.data.total
        }
      }).catch(err => {
        this.isError = true
      }).finally(() => {
        if(this.isError) {
          const time = new Date().toTimeString();
          this.$store.commit('setLogString', '[' + time + ']' + "failed to get memory status")
          this.isError = false
        }
      })
    }
  },
  mounted() {
    this.intervalId = setInterval(this.getMemStat, 10)
  },
  unmounted() {
    clearInterval(this.intervalId)
  }
}
</script>

<style scoped>
  .stat-item {
    color: rgb(22, 93, 255);
    margin: 5px;
}
  .active {
    color: green;
    margin: 5px;
}
</style>