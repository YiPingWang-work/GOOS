package PCBManage
//维护PCB以及恢复进程状态
import (
	"GOOS/Global"
	"GOOS/Hardware"
	"errors"
	"fmt"
)


//页号、【==内存块号、状态位（是否在内存）、访问字段（记录这个页面被访问几次或最近访问时间）、修改位（页面调入内存后是否被修改过）、外存地址（页面在外存中的位置）==】
type PageAtom struct {
	Mem int
	Stat bool
	Frequency int //0变1，1会被舍弃
	IsChange bool
	Disk int //-1代表无对应磁盘
}

//*要求全局性的修改,包括修改PCB内部信息和PC，外层不会再提供任何维护*//

var PCBs [10000]PCB //PCB常驻内存

type PCB struct { //不需要状态字，因为系统已经通过全局变量维护了,pid就是数组索引，也不维护
	Allocated bool
	PID int
	Ppid int
	PC int //执行到代码的逻辑位置，当save的时候会更新
	RegisterState Hardware.RegisterType //寄存器值，当save的时候会更新
	FileTable map[string]int //文件系统
	PageTable []PageAtom //这里把页表存下来，真实的操作系统只会存一个指针,页表常驻内存，当swap的时候会更新，当前PC位置禁止被换出，防止影响load的原子操作
	CodeSiz int //规定PageTable,前CodeSiz块存储的是代码信息，后面的所有都是程序申请的内存
	IsPageFault bool //当前进程状态是否缺页
	Disk int //程序存放的外存地址，一经确认不在改变，虽然UNIX系统分了交换区和文件区
	Flag bool
	Flag2 bool
	LogicAddr int
}

func (this *PCB)IsOut(pc int) (ans bool) {
	ans = false
	if pc < 0 {
		ans = true
	}
	return
}

func (this *PCB)LogicPC(pc int) (myPC int, err error){ //得到逻辑位置
	myPC = 0
	bias := pc % 1024
	mem := pc / 1024
	flag := true
	for i := 0 ; i < len(this.PageTable) ; i ++ {
		if this.PageTable[i].Mem == mem {
			myPC = i * 1024
			flag = false
			break
		}
	}
	if flag {
		err = errors.New("illegal physical address")
		fmt.Println(err)
	}
	myPC += bias
	return
}

func (this *PCB)PhysicPC(PC int) (myPC int, flag bool) { //得到物理位置
	flag = false
	i := PC / 1024
	j := (PC + 1) / 1024
	bias := PC % 1024
	if this.PageTable[j].Stat == false { //没在内存
		myPC = PC
		flag = true
		return
	}
	myPC = this.PageTable[i].Mem * 1024 + bias
	return
}

func (this *PCB)SavePCB() (err error) {
	pc := Global.PC
	//保存逻辑PC值
	this.PC, err = this.LogicPC(pc)
	if this.Flag2 { //最高优先级
		this.PC = this.LogicAddr
	}
	this.Flag2 = false
	this.LogicAddr = -1
	fmt.Println("PCB/保存进程",this.PID,"得到的logic.PC", this.PC)
	//保存寄存器值到this.RegisterState
	this.RegisterState = Hardware.Registers
	return
}

func (this *PCB)LoadPCB() { //如果PC值不在内存，系统的缺页寄存器将设置为1，并将PC寄存器的值改成缺少的===逻辑位置===的上一个地址
	//恢复PC值
	Global.PC, this.IsPageFault = this.PhysicPC(this.PC)
	fmt.Println("PCB/加载进程",this.PID,"得到的Global.physical.PC", Global.PC,"是否缺页",this.IsPageFault)
	if this.Flag {
		this.Flag = false
		Global.PC --
	}
	//各个寄存器的值等于 this.RegisterState
	Hardware.Registers = this.RegisterState
	return
}

func (this *PCB)DeletePCB() (err error) {
	fmt.Println("进程结束后页表为（程序位置）\n====================================================\n内存      状态   磁盘   频率      修改")
	for _, val := range(this.PageTable) {
		fmt.Println(val.Mem, "	 ", val.Stat, "	", val.Disk, " 	", val.Frequency, "	 ", val.IsChange)
	}
	fmt.Println("====================================================")
	this.CodeSiz = 0
	this.PC = 0
	this.IsPageFault = false
	this.PageTable = nil
	this.Allocated = false
	this.FileTable = nil
	this.Flag = false
	return
}

func SortReady() {

	for i := 0 ; i < len(ReadyQueue) ; i ++ {
		if ReadyQueue[i] == 1 {
			for _,val := range(Hardware.Memory.Page[0]) {
				//if val != "" && val != "loop|15" {
				//	goto _BREAK
				//}
				if len(val) > 10 && val[:10] == "newprocess" {
					ReadyQueue = append(ReadyQueue[:i], ReadyQueue[i+1:]...)
					ReadyQueue = append([]int{1}, ReadyQueue...)
					goto _BREAK
				}
			}
			ReadyQueue = append(ReadyQueue[:i], ReadyQueue[i+1:]...)
			ReadyQueue = append(ReadyQueue, 1)
			break
		}
	}
	_BREAK:
}

func CompareWithRunning(pid int) (flag bool) {
	return false
}

func CreatePCB(ppid int, physicalDiskPage *[]int) (pid int, err error) { //返回一个可用PCB的编号，整个过程是New

	/*
	type PCB struct { //不需要状态字，因为系统已经通过全局变量维护了,pid就是数组索引，也不维护
		Allocated int
		PID int
		Ppid int
		PC int //执行到代码的逻辑位置，当save的时候会更新
		RegisterState Hardware.RegisterType //寄存器值，当save的时候会更新
		FileTable map[string]int //文件系统
		PageTable []Global.PageAtom //这里把页表存下来，真实的操作系统只会存一个指针,页表常驻内存，当swap的时候会更新，当前PC位置禁止被换出，防止影响load的原子操作
		IsPageFault bool //当前是否缺页
		Disk int //程序存放的外存地址，一经确认不在改变，虽然UNIX系统分了交换区和文件区
	}
	*/

	pid = len(PCBs)
	for i := 1 ; i < len(PCBs) ; i ++ {
		if PCBs[i].Allocated == false {
			pid = i
			goto _BREAK
		}
	}
_BREAK:
	if pid == len(PCBs) {
		err = errors.New("PCB/there is no empty PCBs")
		return
	}
	PCBs[pid].Allocated = true
	PCBs[pid].PID = pid
	PCBs[pid].Ppid = ppid
	for i := 0 ; i < len(*physicalDiskPage) ; i ++ { //初始化页表
		PCBs[pid].PageTable = append(PCBs[pid].PageTable, PageAtom{
			-1,
			false,
			0,
			false,
			(*physicalDiskPage)[i],
		})
	}
	fmt.Println("新建进程页表为\n====================================================\n内存      状态   磁盘   频率      修改")
	for _, val := range(PCBs[pid].PageTable) {
		fmt.Println(val.Mem, "	 ", val.Stat, "	 ", val.Disk, " 	", val.Frequency, "	 ", val.IsChange)
	}
	fmt.Println("====================================================")
	PCBs[pid].CodeSiz = len(*physicalDiskPage)
	//err = MemmorySystem.MemoryAllocate(pid,  0)
	if err != nil { //一般不会发生错误，只有磁盘容量都不满足的时候发生
		return
	}
	PCBs[pid].PC = -1
	PCBs[pid].FileTable = make(map[string]int)
	return
}