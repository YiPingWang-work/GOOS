import { createApp, } from 'vue'
import ArcoVue from '@arco-design/web-vue'
import ArcoVueIcon from '@arco-design/web-vue/es/icon';
import App from './App.vue'
import '@arco-design/web-vue/dist/arco.css'
import { createStore } from "vuex";

const store = createStore({
  state: {
    LogString: "",
    isNew: false,
  },
  mutations: {
    setLogString(state, msg) {
      state.LogString = msg;
      state.isNew = true;
    },
    clearLogString(state) {
      state.LogString = "";
      state.isNew = false;
    }
  },
  getters: {
    getLogString(state) {
      return {
        LogString: state.LogString,
        isNew: state.isNew
      };
    },
  },
});

const app = createApp(App);
app.use(ArcoVue);
app.use(store);
app.use(ArcoVueIcon).mount('#app')
