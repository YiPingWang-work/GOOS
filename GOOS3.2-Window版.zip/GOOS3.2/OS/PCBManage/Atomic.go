package PCBManage

//原语，不可中断
import (
	"GOOS/Global"
	"errors"
	"fmt"
)

var ReadyQueue []int //就绪队列

var RunningPID int //-1则表示没有在运行中的进程

var WaitingQueue [10][]int //阻塞队列

func Abort(pid int) (err error) {

	if pid == RunningPID {
		err = PCBs[pid].DeletePCB()
		RunningPID = -1
		if len(ReadyQueue) > 0 {
			SortReady()
			RunningPID = ReadyQueue[0]
			ReadyQueue = ReadyQueue[1:]
			PCBs[RunningPID].LoadPCB() //加载新的PCB
		}
		fmt.Println("Atomic/进程终止，终止进程", pid, "启动新进程", RunningPID)
		Global.LOGS = fmt.Sprintf("Atomic/进程终止，终止进程pid:%d,启动新进程pid:%d", pid, RunningPID)
	} else if true /*判断是否在ready队列中*/ { //以下是异常结束情况，或许是硬件错误，主板烧了什么的，先不写

	} else if true /*判断是否在waiting队列中*/ {

	} else if true /*判断是否在suspend队列中*/ {

	} else {
		err = errors.New("Atomic/process doesn't exist")
	}
	return
}

func Switch() { //切换原语，当前running进程进入ready并从ready中拿出一个进程
	pid := RunningPID
	_ = PCBs[pid].SavePCB() //保存PCB
	ReadyQueue = append(ReadyQueue, pid)
	RunningPID = -1
	if len(ReadyQueue) > 0 {
		SortReady()
		RunningPID = ReadyQueue[0]
		ReadyQueue = ReadyQueue[1:]
		PCBs[RunningPID].LoadPCB() //加载新的PCB
	}
	fmt.Println("Atomic/进程切换", pid, "->", RunningPID)
	Global.LOGS = fmt.Sprint("Atomic/进程切换", pid, "->", RunningPID)
	return
}

func Waiting(waitWhat int) { //阻塞原语，当前running进程发生阻塞（请求设备），此时把它放到阻塞队列中,选择一个ready中的执行
	pid := RunningPID
	_ = PCBs[pid].SavePCB() //保存PCB
	WaitingQueue[waitWhat] = append(WaitingQueue[waitWhat], pid)
	RunningPID = -1
	if len(ReadyQueue) > 0 {
		SortReady()
		RunningPID = ReadyQueue[0]
		ReadyQueue = ReadyQueue[1:]
		PCBs[RunningPID].LoadPCB() //加载新的PCB
		fmt.Println("Atomic/进程等待,等待进程", pid, "等待事件", waitWhat, "启动新进程", RunningPID)
		return
	}
	return
}

func Awake(pid int, waitWhat int) (err error) { //唤醒某个waiting中的进程到ready中，再查看是否发生switch
	fmt.Println("Atomic/进程唤醒", pid, "唤醒事件", waitWhat)
	for i := 0; i < len(WaitingQueue); i++ {
		if WaitingQueue[waitWhat][i] == pid {
			ReadyQueue = append(ReadyQueue, pid)
			WaitingQueue[waitWhat] = append(WaitingQueue[waitWhat][:i], WaitingQueue[waitWhat][i+1:]...)
			SortReady()
			if CompareWithRunning(ReadyQueue[0]) { //awake后造成切换
				Switch()
			}
			return
		}
	}
	err = errors.New("Atomic/that process isn't in waiting queue")
	return
}

func New(ppid int, physicalDiskPage *[]int) (pid int, err error) { //新建一个进程，为其分配空间，再查看是否发生switch
	pid, err = CreatePCB(ppid, physicalDiskPage)
	if err != nil {
		fmt.Println(err)
		Global.SuspendReadyQueue = append(Global.SuspendReadyQueue, pid)
	} else {
		ReadyQueue = append(ReadyQueue, pid)
		SortReady()
		if CompareWithRunning(ReadyQueue[0]) { //awake后造成切换,和当前运行进程比一比
			Switch()
		}
	}
	fmt.Println("Atomic/进程新建,新进程", pid)
	Global.LOGS = fmt.Sprintf("Atomic/进程新建,新进程pid:%d,磁盘位置:%v", pid, *physicalDiskPage)
	return
}
