<template>
  <a-table :columns="columns" :data="data"></a-table>
<!--  <a-row :gutter="24">-->
<!--    <a-col :span="22">-->
<!--      -->
<!--    </a-col>-->
<!--    <a-col :span="2">-->
<!--      <a-button type="primary" @click="clear">Clear</a-button>-->
<!--    </a-col>-->
<!--  </a-row>-->
</template>

<script>
import { reactive } from "vue";

export default {
  setup() {
    const columns = [{
      title: "Logs",
      dataIndex: "log",
    }];
    const data = reactive([]);

    return {
      columns,
      data,
    };
  },
  methods: {
    getLogs() {
      const log = this.$store.getters.getLogString;
      if(log.isNew) {
        this.data.push({
          key: (this.data.length + 1).toString(),
          log: log.LogString,
        });
        this.$store.commit("clearLogString");
      }
    },
  },
  mounted() {
    setInterval(this.getLogs, 10);
  },
}
</script>

<style scoped>

</style>