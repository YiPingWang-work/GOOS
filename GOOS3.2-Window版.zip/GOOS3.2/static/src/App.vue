<script setup>
import Logs from "./components/Logs.vue";
</script>

<template>
  <a-layout class="layout-app">
    <a-layout-sider
        theme="dark"
        breakpoint="lg"
        :width="220"
        collapsible
        :collapsed="collapsed"
        @collapse="onCollapse"
    >
      <a-menu
        :default-open-keys="['0']"
        :default-selected-keys="['0']"
        @menu-item-click="onClickMenuItem"
      >
        <a-menu-item key="0">
          <icon-home />
          Home
        </a-menu-item>
        <a-menu-item key="1">
          <icon-dashboard />
          Process Monitor
        </a-menu-item>
        <a-menu-item key="2">
          <icon-storage />
          Memory Monitor
        </a-menu-item>
        <a-menu-item key="3">
          <icon-common />
          Devices Monitor
        </a-menu-item>
      </a-menu>
    </a-layout-sider>
    <a-layout>
      <a-layout-header>
        <span style="font-size: xx-large; color: white">GOOS</span>
      </a-layout-header>
      <a-layout style="padding: 0 24px">
        <a-layout-content>
          <component :is="activeComponent"></component>
        </a-layout-content>
        <a-layout-footer>
          <Logs />
        </a-layout-footer>
      </a-layout>

    </a-layout>
  </a-layout>
</template>

<script>
import {IconHome, IconCommon, IconDashboard} from '@arco-design/web-vue/es/icon';
import ProcessMonitor from "./components/ProcessMonitor.vue";
import MemoryMonitor from "./components/MemoryMonitor.vue";
import DevicesMonitor from "./components/DevicesMonitor.vue";
import ProgramLauncher from "./components/ProgramLauncher.vue";
import axios from "axios";
export default {
  components: {
    IconHome,
    IconCommon,
    IconDashboard,
    ProcessMonitor,
    MemoryMonitor,
    DevicesMonitor,
    ProgramLauncher
  },
  data() {
    return {
      activeComponent: 'ProgramLauncher',
      collapsed: false,
      intervalId: null,
    };
  },
  methods: {
    onCollapse(collapsed) {
      this.collapsed = collapsed;
    },
    onClickMenuItem(key) {
      switch (key) {
        case '0':
          this.activeComponent = 'ProgramLauncher';
          break;
        case '1':
          this.activeComponent = 'ProcessMonitor';
          break;
        case '2':
          this.activeComponent = 'MemoryMonitor';
          break;
        case '3':
          this.activeComponent = 'DevicesMonitor';
          break;
      }
    },
    checkProgram() {
      axios.get("http://localhost:2333/api/check-program").then(res => {
        if (res.data !== "") {
          const time = new Date().toTimeString();
          this.$store.commit('setLogString', '[' + time + ']' + "backend log: " + res.data);
        }
      })
    }
  },
  mounted() {
    this.IntervalId = setInterval(this.checkProgram, 10);
  },
  unmounted() {
    clearInterval(this.IntervalId);
  }
}
</script>

<style scoped>
.layout-app {
  border: var(--color-border);
  height: 100vh;
}

.layout-app :deep(.arco-layout-header) {
  height: 64px;
  line-height: 64px;
  background: rgb(var(--arcoblue-6));
}
</style>
