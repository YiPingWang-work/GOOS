package main

import (
	"GOOS/Global"
	"GOOS/Hardware"
	"GOOS/Interrupt"
	"GOOS/OS"
	"GOOS/OS/PCBManage"
	"GOOS/OS/Process"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"
)

var timeSlice int

var Ostime int
var Cnt int
var lastPC int

func execute() bool {
	//Global.LOGS = ""
	time.Sleep(time.Millisecond * time.Duration(Ostime))
	var err error
	lastPC = Global.PC
	Global.PC++                 //PC ++
	if Global.PC%1024 == 1023 { //这条指令执行到某个页面的最后一个"字节"，则直接让他执行完发生进程切换
		timeSlice = 0
		fmt.Println("CPU/强制时间片到期")
	}
	fmt.Printf("------------ PID=%d PC=%d Page=%d ------------>", PCBManage.RunningPID, Global.PC, Global.PC/1024)
	//检查是否越界
	if Global.PC < 0 { //越界【【【【【【【【【【【【【【【这里实现的不好】】】】】】】】】】】】】】】】】】】】】
		fmt.Println("CPU/越界进程终止")
		err = Process.SystemCall(Interrupt.Trap{ //进程终止
			Interrupt.ABORTPROCESS, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			"",
			0,
			0,
			0,
			"",
		})
		return true
	}
	//检查PC是否缺页
	if PCBManage.PCBs[PCBManage.RunningPID].IsPageFault || Hardware.Memory.PageHolder[Global.PC/1024] != PCBManage.RunningPID { //缺页
		//if !PCBManage.PCBs[PCBManage.RunningPID].IsPageFault {
		//	PCBManage.PCBs[PCBManage.RunningPID].IsPageFault = true
		//	fmt.Println("!!!!!!!!!!!!（程序位置）\n====================================================\n内存      状态   磁盘   频率      修改")
		//	for _, val := range(PCBManage.PCBs[PCBManage.RunningPID].PageTable) {
		//		fmt.Println(val.Mem, "	 ", val.Stat, "	", val.Disk, " 	", val.Frequency, "	 ", val.IsChange)
		//	}
		//	fmt.Println("====================================================")
		//	Global.PC,_ = PCBManage.PCBs[PCBManage.RunningPID].LogicPC(PCBManage.RunningPID)
		//	fmt.Println("=====================================================================================================================",Global.PC)
		//}else{
		//	Global.PC --
		//}
		Global.PC--
		fmt.Println("CPU/缺页,缺逻辑页", (Global.PC+1)/1024, "逻辑PC", Global.PC+1)
		Global.LOGS = fmt.Sprintf("CPU/缺页,缺逻辑页:%d,逻辑PC:%d", (Global.PC+1)/1024, Global.PC+1)
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.PAGEFAULT,
			0,
			PCBManage.RunningPID,
			[]int{},
			(Global.PC + 1) / 1024,
			0,
			"",
			0,
			0,
			0,
			"",
		})
		return true
	}

	//取指令
	cmd := &(Hardware.Memory.Page[Global.PC/1024][Global.PC%1024])
	cmds := strings.Split(*cmd, "|")
	//执行
	flag, err := nomalInstruction(PCBManage.RunningPID, *cmd)
	if err != nil {
		//fmt.Println("================================================================================================================================")
		fmt.Println(err)
		cmds[0] = "abortprocess"
	}
	if !flag && err == nil {
		return false
	}

	if cmds[0] == "openfile" { //打开文件
		fmt.Println("CPU/打开文件", cmds[1])
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.OPENFILE, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			cmds[1], //有效位
			0,
			0,
			0,
			"",
		})
	} else if cmds[0] == "readfile" { //读文件
		fmt.Println("CPU/读文件", cmds[1])
		t, _ := strconv.Atoi(cmds[2])
		t2, _ := strconv.Atoi(cmds[3])
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.READFILE, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			t,       //有效位
			cmds[1], //有效位
			t2,      //有效位
			0,
			0,
			"",
		})
	} else if cmds[0] == "writefile" { //写文件
		fmt.Println("CPU/写文件", cmds[1])
		t, _ := strconv.Atoi(cmds[2])
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.WRITEFILE, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			t,
			cmds[1], //有效位
			0,       //和这个文件有关的全部写回
			0,
			0,
			cmds[3], //文件内容
		})
	} else if cmds[0] == "createfile" { //创建文件
		fmt.Println("CPU/创建文件", cmds[1])
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.CREATEFILE, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			cmds[1], //有效位
			0,
			0,
			0,
			"",
		})
	} else if cmds[0] == "closefile" { //关闭文件
		fmt.Println("CPU/关闭文件", cmds[1])
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.CLOSEFILE, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			cmds[1], //有效位
			0,
			0,
			0,
			"",
		})
	} else if cmds[0] == "newprocess" { //新建进程
		t := []int{}
		for i := 1; i < len(cmds); i++ {
			t1, _ := strconv.Atoi(cmds[i])
			t = append(t, t1)
		}
		fmt.Println("CPU/新建进程，程序所在的物理块号是", t)
		Global.LOGS = fmt.Sprintf("CPU/新建进程，程序所在的物理块号是:%v", t)
		//冲掉原有进程，这一点我设计的特别诡异。。。。。。
		*cmd = ""
		fmt.Println(Hardware.Memory.Page[0][:16])
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.NEWPROCESS, //有效位
			0,
			PCBManage.RunningPID, //有效位
			t,                    //有效位
			0,
			0,
			"",
			0,
			0,
			0,
			"",
		})

	} else if cmds[0] == "abortprocess" { //终止进程
		fmt.Println("CPU/进程终止")
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.ABORTPROCESS, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			"",
			0,
			0,
			0,
			"",
		})
	} else if cmds[0] == "memoryapply" { //内存申请
		t, _ := strconv.Atoi(cmds[1])
		fmt.Println("CPU/内存申请 siz", t)
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.MEMORYAPPLY, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			"",
			0,
			0,
			t, //有效位
			"",
		})
		if err != nil {
			fmt.Println("CPU/内存错误 ", err)
		}
	} else if cmds[0] == "deviceapply" { //设备
		t, _ := strconv.Atoi(cmds[1])
		fmt.Println("CPU/设备申请，id=", t)
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.DEVICEAPPLY, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			"",
			0,
			t, //有效位
			0,
			"",
		})
	} else if cmds[0] == "deviceinstall" {
		t, _ := strconv.Atoi(cmds[1])
		fmt.Println("CPU/设备安装，id=", t)
		err = Process.SystemCall(Interrupt.Trap{
			Interrupt.DEVICEINSTALL, //有效位
			0,
			PCBManage.RunningPID, //有效位
			[]int{},
			0,
			0,
			"",
			0,
			t, //有效位
			0,
			"",
		})
	} else {
		fmt.Println("CPU/illegal command")
	}
	return true
}

//我希望实现一个修改内存中某段的函数，这个函数是和当前的PC值有关的，而不会发生跳转
func nomalInstruction(pid int, cmd string) (flag bool, err error) {
	flag = false
	if cmd == "" || len(cmd) < 4 { //常规指令
		_, err1 := strconv.Atoi(cmd)
		if err1 == nil {
			fmt.Println("全局数据区")
			return
		}
		if PCBManage.RunningPID == 1 {
			fmt.Println("CPU/空闲")
			Global.LOGS = fmt.Sprintf("CPU/空闲(1号程序)")
		} else {
			fmt.Println("CPU/未定义指令")
		}
		return
	} else if cmd[:4] == "loop" { //循环指令
		t, _ := strconv.Atoi((cmd)[5:])
		lPC := Global.PC
		Global.PC -= t + 1
		if PCBManage.RunningPID != 1 && Global.PC/1024 == lPC/1024 {
			fmt.Println("CPU/循环 loop=", t, ", 新PC=", Global.PC+1)
		} else if PCBManage.RunningPID == 1 {
			fmt.Println("CPU/空闲")
			Global.LOGS = fmt.Sprintf("CPU/空闲(1号程序)")
		} else { //loop执行后程序跳转到另外一个页面了
			logicPC, _ := PCBManage.PCBs[PCBManage.RunningPID].LogicPC(lPC) //得到当前指令的逻辑pc值
			logicPC -= t + 1                                                //得到跳转到的指令的逻辑PC值（是上一条）
			PCBManage.PCBs[PCBManage.RunningPID].Flag2 = true
			PCBManage.PCBs[PCBManage.RunningPID].LogicAddr = logicPC
			timeSlice = 0
			fmt.Println("CPU/loop跳转后指令换页,跳转后的逻辑PC", logicPC)
			fmt.Println("CPU/强制时间片到期")
		}
		return
	}
	fmt.Println("CPU/定义指令", cmd)
	cmds := strings.Split(cmd, "|")
	switch cmds[0] {
	case "add_": //add_|a|b|c
		a, _ := strconv.Atoi(cmds[1])
		b, _ := strconv.Atoi(cmds[2])
		c, _ := strconv.Atoi(cmds[3])
		if a > 31 || b > 31 || c > 31 {
			err = errors.New("register error")
			return
		}
		Hardware.Registers.Axs[c] = Hardware.Registers.Axs[b] + Hardware.Registers.Axs[a]
	case "mul_": //mul_|a|b|c
		a, _ := strconv.Atoi(cmds[1])
		b, _ := strconv.Atoi(cmds[2])
		c, _ := strconv.Atoi(cmds[3])
		if a > 31 || b > 31 || c > 31 {
			err = errors.New("register error")
			return
		}
		Hardware.Registers.Axs[c] = Hardware.Registers.Axs[b] * Hardware.Registers.Axs[a]
	case "div_": //div_|a|b|c
		a, _ := strconv.Atoi(cmds[1])
		b, _ := strconv.Atoi(cmds[2])
		c, _ := strconv.Atoi(cmds[3])
		if a > 31 || b > 31 || c > 31 {
			err = errors.New("register error")
			return
		}
		if Hardware.Registers.Axs[b] == 0 {
			err = errors.New("divide by zero，进程终止")
			return
		}
		Hardware.Registers.Axs[c] = Hardware.Registers.Axs[a] / Hardware.Registers.Axs[b]
	case "load": //load|a|b 加载a逻辑内存地址的东西到b寄存器,这个逻辑地址的东西==必须==在内存里面
		a, _ := strconv.Atoi(cmds[1])
		b, _ := strconv.Atoi(cmds[2])
		if b > 31 {
			err = errors.New("register error")
			return
		}
		if len(PCBManage.PCBs[pid].PageTable) <= a/1024 || PCBManage.PCBs[pid].PageTable[a/1024].Stat == false {
			err = errors.New("memory error in that command")
			return
		}
		content, _ := strconv.Atoi(Hardware.Memory.Page[PCBManage.PCBs[pid].PageTable[a/1024].Mem][a%1024])
		Hardware.Registers.Axs[b] = content
		PCBManage.PCBs[pid].PageTable[a/1024].IsChange = true
		fmt.Println("CPU/执行load指令，得到的值是", content, "放在寄存器Axs", b, "中")
		fmt.Println("现在寄存器值是\n====================================================")
		for _, val := range Hardware.Registers.Axs {
			fmt.Print(val, " ")
		}
		fmt.Println("\n====================================================")
	case "save": //save|a|b 将寄存器为a地方的东西放到逻辑地址b里面
		a, _ := strconv.Atoi(cmds[1])
		b, _ := strconv.Atoi(cmds[2])
		if a > 31 {
			err = errors.New("register error")
			return
		}
		if len(PCBManage.PCBs[pid].PageTable) <= b/1024 || PCBManage.PCBs[pid].PageTable[b/1024].Stat == false {
			err = errors.New("memory error in that command")
			return
		}
		content := strconv.Itoa(Hardware.Registers.Axs[a])
		Hardware.Memory.Page[PCBManage.PCBs[pid].PageTable[b/1024].Mem][b%1024] = content
		fmt.Println("CPU/执行save指令存储的值是", content, "放在内存", b, "处")
		fmt.Println("此时该内存位置的值是", Hardware.Memory.Page[PCBManage.PCBs[pid].PageTable[b/1024].Mem][b%1024])
	default:
		flag = true
	}
	return
}

func Run() {
	timeSlice = 5 //重制时间片
	for {

		if execute() { //执行程序，如果中断处理，本次不处理外部中断
			continue
		}

		select { //外中断发生，陷入操作系统处理
		case interrupt := <-Global.BUS:
			if interrupt.Type != 0 { //外部中断
				err := OS.INT(&interrupt)
				if err != nil {
					fmt.Println(err)
				}
			} else { //用户接口调用
				err := OS.UserInterface(interrupt.Command)
				if err != nil {
					fmt.Println(err)
				}
			}
		default:
			break
		}
		if timeSlice > 0 {
			timeSlice--
		} else {
			timeSlice = 25
			//时间片到期切换进程
			if len(PCBManage.ReadyQueue) > 0 {
				PCBManage.Switch()
			}
		}
		Cnt--
		if Cnt == 0 {
			break
		}
	}
}
