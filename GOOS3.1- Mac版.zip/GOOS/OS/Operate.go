package OS

import (
	"GOOS/Interrupt"
	"GOOS/OS/Process"
)

//中断处理程序，也是操作系统的核心，这两个可以写成一个函数其实


func INT(interrupt *Interrupt.Interrupt) (err error){ //内部中断处理，处理系统调用，错误和中止
	err = Process.INTExecute(interrupt) //处理中断
	return
}

func UserInterface(command string) (err error) { //用户接口

	return
}



