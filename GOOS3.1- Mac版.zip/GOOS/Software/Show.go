package Software

import (
	"GOOS/Hardware"
	"GOOS/OS/IO"
	"bufio"
	"errors"
	"fmt"
	"os"
	"strconv"
)

var HashMap[200][]int

func StartNewWork(Wid int) (err error){
	flag := false
	for i := 1 ; i < 15 ; i ++ {
		fmt.Println("-------------------------------------------------------------------------------",Wid)
		if Hardware.Memory.Page[0][i] == "" {
			flag = true
			Hardware.Memory.Page[0][i] = "newprocess"
			for _, j := range HashMap[Wid] {
				Hardware.Memory.Page[0][i] += "|" + strconv.Itoa(j) //冲掉原有进程开启新进程
			}
			break
		}
	}
	fmt.Println("【【【【外部命令进程",Wid,"启动】】】】")
	if !flag {
		err = errors.New("too quick, failed")
		fmt.Println(err)
	}
	return
}


func OS_init() (ostime int, cnt int){
	ii := 0
	u := 1
	commands := []string{}
	fd, err := os.Open("./in.in")
	if err != nil {
		fmt.Println(err)
	}
	defer fd.Close()
	fileScan := bufio.NewScanner(fd)
	for fileScan.Scan() {
		commands = append(commands, fileScan.Text())
	}
	num, err := strconv.Atoi(commands[ii])
	fmt.Println("你设置了",num,"个程序")
	ii ++
	if err != nil {
		fmt.Println("bad input")
		os.Exit(-1)
	}
	for i := 0 ; i < num ; i ++ {
		block, err := strconv.Atoi(commands[ii])
		fmt.Println("你的第",i,"个作业需要",block,"个磁盘空间")
		ii ++
		if err != nil {
			fmt.Println("bad input")
			os.Exit(-1)
		}
		wid, err := strconv.Atoi(commands[ii])
		fmt.Println("你的第",i,"个作业加入到",wid,"远程控制")
		ii ++
		if err != nil {
			fmt.Println("bad input")
			os.Exit(-1)
		}
		for k := 0 ; k < block ; k ++ {
			block1, err := strconv.Atoi(commands[ii])
			HashMap[wid] = append(HashMap[wid], block1)
			ii ++
			if err != nil {
				fmt.Println("bad input")
				os.Exit(-1)
			}
		}
		fmt.Println("第",i,"个作业磁盘块为",HashMap[wid])
		line, err := strconv.Atoi(commands[ii])
		fmt.Println("你的第",i,"个程序有多少有效行（机器字）",line)
		ii ++
		if err != nil {
			fmt.Println("bad input")
			os.Exit(-1)
		}
		for j := 0 ; j < line ; j ++ {
			t, err := strconv.Atoi(commands[ii])
			ii ++
			if err != nil {
				fmt.Println("bad input")
				os.Exit(-1)
			}
			IO.DeviceBuffer[0][HashMap[wid][0] + t / 1024][t % 1024] = commands[ii]
			fmt.Println("给出逻辑第",t,"行的内容为",IO.DeviceBuffer[0][HashMap[wid][0] + t / 1024][t % 1024])
			ii ++
		}
		flag, err := strconv.Atoi(commands[ii])
		ii ++
		if err != nil {
			fmt.Println("bad input")
			os.Exit(-1)
		}
		fmt.Println("你规定了第",i,"个程序,你是否需要boot进程(1号进程)新建它", flag)
		if flag == 1 {
			Hardware.Memory.Page[0][u] = "newprocess"
			for _, j := range HashMap[wid] {
				Hardware.Memory.Page[0][u] += "|" + strconv.Itoa(j) //冲掉原有进程开启新进程
			}
		}
		fmt.Println("设置成功，下面进行下一程序的设置\n")
	}
	fmt.Println("全部作业设置已完成，设置CPU执行一条指令的时间")
	ostime, err = strconv.Atoi(commands[ii])
	ii ++
	if err != nil || ostime <= 0 {
		ostime = 400
		fmt.Println("默认时间400ms")
	}else {
		fmt.Println("你设置时间为",ostime)
	}
	fmt.Print("设置CPU运行几步 ")
	cnt, err = strconv.Atoi(commands[ii])
	ii ++
	if err != nil || cnt <= 0 {
		cnt = -1
		fmt.Println("一直运行")
	}else {
		fmt.Println("你设置时间运行",cnt,"步")
	}
	return
}
