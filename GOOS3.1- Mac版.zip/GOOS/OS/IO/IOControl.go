package IO

import (
	"GOOS/Global"
	"GOOS/Hardware"
	"GOOS/Interrupt"
	"time"
)

// Device 设备信息
type Device struct {
	Status   int
	PidFirst *PidListItem
	PidLast  *PidListItem
}

var Devices map[int]*Device

type PidListItem struct {
	Pid         int
	Time        int
	instruction Instruction
	Next        *PidListItem
}

// Instruction IO指令
type Instruction struct {
	Operation  int //操作
	DeviceId   int //设备号
	Pid        int //进程id
	Time       int //占用时间
	MemoryAddr int //内存地址
	BufferAddr int //外设地址
	SubType    int
}

const (
	Shutdown = iota
	Install
	Apply
	In
	Out
	ReadFile
	WriteFile
)

const (
	DeviceStatusIdle = iota
	DeviceStatusOccupied
)

var InstructionChan chan Instruction

var DeviceBuffer map[int]*[1024][1024]string

// initialize 初始化，自动安装设备0作为磁盘
func initialize() {
	Devices = make(map[int]*Device)
	InstructionChan = make(chan Instruction, 10)
	DeviceBuffer = make(map[int]*[1024][1024]string)

	InstallDevice(0)
}

// InstallDevice 安装设备
func InstallDevice(deviceId int) {
	//新建设备，写入设备信息
	device := new(Device)
	device.Status = 0
	device.PidFirst = nil
	device.PidLast = nil

	Devices[deviceId] = device

	//新建缓冲
	DeviceBuffer[deviceId] = new([1024][1024]string)

	return
}

// ApplyDevice 申请设备
func ApplyDevice(instruction Instruction) {
	//获取设备信息
	device := Devices[instruction.DeviceId]
	//检查设备状态
	//如果设备空闲
	if device.Status == 0 {
		pidListItem := new(PidListItem)
		pidListItem.Pid = instruction.Pid
		pidListItem.Time = instruction.Time
		pidListItem.instruction = instruction
		pidListItem.Next = nil

		//将进程挂载至队列
		device.PidFirst = pidListItem
		device.PidLast = pidListItem

		//设备设置占用状态
		device.Status = 1
	} else {
		if device.PidLast == nil {
			//device.Status = 0
			device.PidFirst = nil
			//return
		}
		pidListItem := new(PidListItem)
		pidListItem.Pid = instruction.Pid
		pidListItem.Time = instruction.Time
		pidListItem.instruction = instruction
		pidListItem.Next = nil

		//将进程挂载至队列
		device.PidLast.Next = pidListItem
		device.PidLast = pidListItem
	}
	return
}

// DataIn 数据从io读入内存
func DataIn(instruction Instruction) {
	//占用外设
	ApplyDevice(instruction)
	//fmt.Println("--------------------------------------------------",instruction.DeviceId,",",instruction.BufferAddr)
	bufferData := DeviceBuffer[instruction.DeviceId][instruction.BufferAddr]
	for i := 0; i < 1024; i++ {
		Hardware.Memory.Page[instruction.MemoryAddr][i] = bufferData[i]
	}
}

// DataOut 数据从内存输出至io
func DataOut(instruction Instruction) {
	//占用外设
	ApplyDevice(instruction)

	memoryData := Hardware.Memory.Page[instruction.MemoryAddr]
	for i := 0; i < 1024; i++ {
		DeviceBuffer[instruction.DeviceId][instruction.BufferAddr][i] = memoryData[i]
	}
}

//根据时钟信号给出的时间片模拟时间推进
func executeDevice() (pidDone []int, deviceDone []int, instructionDone []Instruction) {
	//找到被占用的设备，减少占用时间
	for id, device := range Devices {
		if device.Status == DeviceStatusOccupied {
			//检查队列指针是否正常
			if device.PidFirst == nil || device.PidLast == nil {
				device.Status = DeviceStatusIdle
				continue
			}
			//检查是否有剩余时间
			if device.PidFirst.Time > 0 {
				device.PidFirst.Time--
			}
			//检查剩余时间是否耗尽
			if device.PidFirst.Time <= 0 {
				//返回设备id,Pid,instruction信息
				pidDone = append(pidDone, device.PidFirst.Pid)
				deviceDone = append(deviceDone, id)
				instructionDone = append(instructionDone, device.PidFirst.instruction)

				//队列指针后移
				device.PidFirst = device.PidFirst.Next
			}
			//检查剩余进程是否耗尽
			if device.PidFirst == nil {
				device.PidLast = nil
				device.Status = DeviceStatusIdle
			}
		}
	}

	return
}

//初始化启动块
func initializeBootBlock() {
	//DeviceBuffer[0][7][6]="createfile|/helloworld"
	//DeviceBuffer[0][7][10]="memoryapply|10"
	//DeviceBuffer[0][7][20]="openfile|/helloworld"
	//DeviceBuffer[0][7][21]="writefile|/helloworld|0|ABCDEF"
	//DeviceBuffer[0][7][22]="readfile|/helloworld|2|3"
	//DeviceBuffer[0][7][27]="writefile|/helloworld|2|12345999uy"
	//DeviceBuffer[0][7][30]="readfile|/helloworld|0|11"
	//DeviceBuffer[0][7][32]="closefile|/helloworld"
	////DeviceBuffer[0][7][33]="openfile|/helloworld"
	////DeviceBuffer[0][7][32]="readfile|/helloworld|0|3"
	////DeviceBuffer[0][7][34]="closefile|/helloworld"
	////DeviceBuffer[0][7][37]="abortprocess"
	//DeviceBuffer[0][7][33]="newprocess|8|9"
	//DeviceBuffer[0][7][34] = "abortprocess"
	////
	////DeviceBuffer[0][8][3]="openfile|/helloworld"
	//////DeviceBuffer[0][6][5]="writefile|/helloworld|0|ijkoopuuu"
	////DeviceBuffer[0][8][10]="readfile|/helloworld|2|3"
	////DeviceBuffer[0][8][11]="closefile|/helloworld"
	////DeviceBuffer[0][9][12]="abortprocess"

}

// StartDevice 启动io
func StartDevice() {
	initialize()
	initializeBootBlock()
	for {
		//检查是否有指令
		select {
		case instruction := <-InstructionChan:
			switch instruction.Operation {
			case Shutdown:
				return
			case Install:
				InstallDevice(instruction.DeviceId)
			case Apply:
				ApplyDevice(instruction)
			case In:
				DataIn(instruction)
			case Out:
				DataOut(instruction)
			case ReadFile:
				ApplyDevice(instruction)
			case WriteFile:
				ApplyDevice(instruction)
			}
		default:
		}

		//检查是否有外设执行完
		pidDone, deviceDone, instructionDone := executeDevice()
		//pidDone, deviceDone, _ := executeDevice()
		for i, pid := range pidDone {
			//发送中断

			interrupt := Interrupt.Interrupt{
				Type:             0,
				SubType:          instructionDone[i].SubType,
				Priority:         0,
				Pid:              pid,
				Device:           deviceDone[i],
				PhysicalPageNum:  instructionDone[i].MemoryAddr,
				PhysicalBlockNum: instructionDone[i].BufferAddr,
				Command:          "",
			}
			switch instructionDone[i].Operation {
			case ReadFile:
				interrupt.Type = Interrupt.E_READFILE
			case WriteFile:
				interrupt.Type = Interrupt.E_WRITEFILE
			default:
				interrupt.Type = instructionDone[i].Operation
			}

			Global.BUS <- interrupt
		}
		time.Sleep(time.Second)
	}
}

// GetIOInfo 获取设备表信息
func GetIOInfo() (devicesInfo *map[int]*Device) {
	return &Devices
}
