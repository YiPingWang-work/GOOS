package Hardware

type MemoryType struct {//内存有51页，每页1024指令量
	PageHolder [51]int //存内存页的占有者，未占有为0
	FreePages []int //存空闲内存页
	PageState [51]int //三种state，一种正在读，一种正在写，一种未处理
	PageClock [51]int //当前页面使用次数
	Page [51][1024]string //内存中"一字节"的内容
	Buffer [10000][][]byte //IO缓冲区 下标依次是进程，哪个文件，文件内容是[]byte
	MyCommand string //总控制
}

var Memory MemoryType
